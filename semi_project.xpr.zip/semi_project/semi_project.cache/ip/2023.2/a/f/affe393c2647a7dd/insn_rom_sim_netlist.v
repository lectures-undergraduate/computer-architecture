// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2023.2 (win64) Build 4029153 Fri Oct 13 20:14:34 MDT 2023
// Date        : Thu Jun 18 21:53:23 2026
// Host        : DESKTOP-D1BDUE3 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ insn_rom_sim_netlist.v
// Design      : insn_rom
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "insn_rom,dist_mem_gen_v8_0_14,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dist_mem_gen_v8_0_14,Vivado 2023.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (a,
    spo);
  input [3:0]a;
  output [31:0]spo;

  wire \<const0> ;
  wire [3:0]a;
  wire [28:0]\^spo ;
  wire [31:0]NLW_U0_dpo_UNCONNECTED;
  wire [31:0]NLW_U0_qdpo_UNCONNECTED;
  wire [31:0]NLW_U0_qspo_UNCONNECTED;
  wire [31:4]NLW_U0_spo_UNCONNECTED;

  assign spo[31] = \<const0> ;
  assign spo[30] = \<const0> ;
  assign spo[29] = \<const0> ;
  assign spo[28:26] = \^spo [28:26];
  assign spo[25] = \<const0> ;
  assign spo[24] = \<const0> ;
  assign spo[23] = \<const0> ;
  assign spo[22] = \^spo [22];
  assign spo[21] = \<const0> ;
  assign spo[20] = \<const0> ;
  assign spo[19] = \<const0> ;
  assign spo[18] = \<const0> ;
  assign spo[17] = \<const0> ;
  assign spo[16] = \<const0> ;
  assign spo[15] = \<const0> ;
  assign spo[14] = \<const0> ;
  assign spo[13] = \<const0> ;
  assign spo[12] = \<const0> ;
  assign spo[11] = \<const0> ;
  assign spo[10] = \<const0> ;
  assign spo[9] = \<const0> ;
  assign spo[8] = \<const0> ;
  assign spo[7] = \<const0> ;
  assign spo[6] = \<const0> ;
  assign spo[5] = \<const0> ;
  assign spo[4] = \<const0> ;
  assign spo[3:0] = \^spo [3:0];
  GND GND
       (.G(\<const0> ));
  (* C_FAMILY = "artix7" *) 
  (* C_HAS_D = "0" *) 
  (* C_HAS_DPO = "0" *) 
  (* C_HAS_DPRA = "0" *) 
  (* C_HAS_I_CE = "0" *) 
  (* C_HAS_QDPO = "0" *) 
  (* C_HAS_QDPO_CE = "0" *) 
  (* C_HAS_QDPO_CLK = "0" *) 
  (* C_HAS_QDPO_RST = "0" *) 
  (* C_HAS_QDPO_SRST = "0" *) 
  (* C_HAS_WE = "0" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_PIPELINE_STAGES = "0" *) 
  (* C_QCE_JOINED = "0" *) 
  (* C_QUALIFY_WE = "0" *) 
  (* C_REG_DPRA_INPUT = "0" *) 
  (* c_addr_width = "4" *) 
  (* c_default_data = "0" *) 
  (* c_depth = "16" *) 
  (* c_elaboration_dir = "./" *) 
  (* c_has_clk = "0" *) 
  (* c_has_qspo = "0" *) 
  (* c_has_qspo_ce = "0" *) 
  (* c_has_qspo_rst = "0" *) 
  (* c_has_qspo_srst = "0" *) 
  (* c_has_spo = "1" *) 
  (* c_mem_init_file = "insn_rom.mif" *) 
  (* c_parser_type = "1" *) 
  (* c_read_mif = "1" *) 
  (* c_reg_a_d_inputs = "0" *) 
  (* c_sync_enable = "1" *) 
  (* c_width = "32" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_dist_mem_gen_v8_0_14 U0
       (.a(a),
        .clk(1'b0),
        .d({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .dpo(NLW_U0_dpo_UNCONNECTED[31:0]),
        .dpra({1'b0,1'b0,1'b0,1'b0}),
        .i_ce(1'b1),
        .qdpo(NLW_U0_qdpo_UNCONNECTED[31:0]),
        .qdpo_ce(1'b1),
        .qdpo_clk(1'b0),
        .qdpo_rst(1'b0),
        .qdpo_srst(1'b0),
        .qspo(NLW_U0_qspo_UNCONNECTED[31:0]),
        .qspo_ce(1'b1),
        .qspo_rst(1'b0),
        .qspo_srst(1'b0),
        .spo({NLW_U0_spo_UNCONNECTED[31:29],\^spo }),
        .we(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2023.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
uwBH4JaTzmENPjp1VK18+NmHqz3idKCCPayqakkK6bYDVk0JtRfycJYNxbcnLmlw5yuLTcDXBBKk
FqBPE2n7wWKg9tfz2Y8PrWAvnbsIFMfxBK8sfWUf8PPnz8vUwwMHjbXUWcgCgvtygj/TbB+jcZ8Z
CjYnBZ8tNdKOO1iDLpQ=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Ff7o4KDFniNgPFT3cDZtw4HhiKzFbOFtLXtuci0MZhgQ8oZ15BcuowAfxUJXngU8JkWI9cbWKkG8
h/PODwnWEt4eK4VDKRk6Hw3QkZiKAa1N3QupC8D5bR7vJ/+RhJwSayz9t2JpdZaEhKgCgqTcX6oZ
4fCEOmSTUWVob+DXV4UfaMyfVm5VI0wxZ7q0mjFx+pdkt56PuNREX9kH4a9Ma1P0sYo8XaTpANLa
JC6eXOuUQlp40M9F/NL1Xajpys0YfGx8AveMAFEyfRmHZs+NbXmny/79vednrm+FhwtS9LveegmF
NZW9jiiR+9Igeraaz+QXPc6JO/nCDTr4Fuwusg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
enb/INzHPP7GNdz8dyyqgVCJiMs9JXcjMywZXhzPersGm0A258UOUwtOqcF1rO7lnrKwTeWbNFVN
dO3BxXBpzGnYWUqDda208CYV9hTWFhfySQdX58qn1Z8QY5G7KniMCVjaGuPPCfToPOOdbAxR9XUp
XbMr0vrZKWxz8nBhGYc=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
RKZNANfa63/n14iwmSxsB/UeV76BNqjEiYgjlZ2LdFWOArCv6D+jhC4sjGMiaz8GJ8J5kQeiWB0Y
e1+zdHflgzODs6eVC82MlEcfgP0vdDIBn0PP8rVDg5O31eQuJ7n5zn4XJu+vzjpkvJIHKrktAsP4
jg+LRxcTOu0dILImk7Vwgyuwhi8OxNN+jBVbLVxdNj0l5aQMgRZlU/8FVh3u958SH7z/fHnwGaOw
P8QgNv0ZZblWvpxa8TJIwlgVb9354a0eyD9XsKy5VfuUG03nmputxNzUuIUmGtBGCqx+4D4pyCch
j/ixD5iiKRmeKD1/RtGzxmrJap7SAHMuzic1Hw==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
OQMD0qoDy+4W8+jfTV63GDTwmjWvJILCTofeYJTZqWc2KhrzQXwVMW48dTyIriC6bA4bmXD5BwcB
W2gGbVUvY1Y1+wEFEwYIC0LiPrJO0DhpM1JhP2vkxnTEwaODiEp5x3XqHgsiys0I2/9mE4z4Hlbl
jzftQ/8sVSYokhMp9eaIHk3HNCSBllv90qeBfH3fOdVI2gA1r/22PktttbkyKji24r7jM5o4aMIc
Sp6u0DCnD2cSPCuCuMW3A9sFRuTKbXiLAeeymFIAXHKYQgWXXOqmbKHrk4GviHQyz31C9d+hm6dh
RMtaCyWnhqo3QE/QxP0TsYk3CgkjDCU+KK/ozA==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2022_10", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
uV1eryjGs1SHbpKIAk5r3BY2SLKX9RlfGw6gbw/UtzBYt4U7vTBIy+x767ojEcmbGLos8kr8vilV
cnNOnsbu7vOAUIe+1PgpaPaCkv2OTPXaE0tfps6+Q6D3zB6j2a2FE1gRIPOniwAdlIn69jL2tuWD
M2BN1efQhi0lZHuKtTgzBOVXIg+zbTiH2k2kHWThOi6WayoBEny+g88wRi6pUBeB6aW3ezFYNmsl
zeOY9xmt+UhRMcr87DCcZdmjsIk6VrsIKF60y93pM0IoQ56iWpQ2OKZK+Ng9qC+pNHBEYEhiMQFb
kUesHtcFOIS7Ok6S9O9SMgf7lMQFOh9w0L31UA==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GM2VxmvaiVBg1DsqOLewt6rcWtfH/Gj1QS7fUSMudF5qJ2fn+TXd8kcCwwrxdcXNXjoVi2As5jmL
yw1/NZreemrkS1YCJJDxmnE8CW2q9/4N4a79kApF1VfD5XdpaULhVn+Eb+jXCQFG+GEEOvnPb0Me
bbfRkfc0DAIWgtG2D81EQ28mg7KAWtsDpdUCi+BKdIAj8RXoTiQbFbiBeT7EiRIrz2PQF9nhQBfF
FjlrCNwDP4hRQJQeZcf/1Pl8SFyKGQb6iVF+VhhCVCunL7VBmzaCOW/gowPM7hRM2dvzmxcgeKfs
dZx/fy2rk1iokUi+3B+Jc6CycMWbHu8EfCh7iQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
NSZoNMCco4gpYPcg8pb9mtee1JxEWDcDzt6wnS0LeSPMi2upLvQXnSQKMvJGGOKStJOcu1eu7x33
4Xa3ApbjbfZ+lgs1PYlyY4V+B2Lio1EEo1uzZVWFrVFvmknOZwj6Gcmj5N/osaiqKaeIw7NTTbyX
HNHOabVsQJ540qnP4u/nzS/h/AQcm0PFLadGZtHJZEzyQDSSdghD/y/OLprdBcInfQDwAxQuJpCy
ExX4lD2WMrCkymNBS9NMH0vYh4kvpYKRO/oHuGcOZVg0p8vfMmz/BJDHuxTcS3FpLT0WxGVcmUIk
cuqKQFiVwwgnW9AfYkbsMrwfl9po2pofaAY2JC5ZTMyO1qEfSu4fxTRJNnDRvW65KkMdJhZFa36p
82hcDlaYvBowndZfMc42Sxt+ZULFDTFN0HT50iteAG1yEvJ9jKBiJla+kDQJB0VD0kj4+k8aBug3
uPKVykvf1/Uaw8NoW591pML42qlh8v1RzAm6aDnPRdsDaCc5Dq9QDPuE

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
oRNld8VrAuP/xHUguZzkh8+wROOItnvw1FQUP5KHjxeh8nudEYH2PGefTPsV73QyEruJanGifjCR
m8XHiIxqAY9fk4CAm+2n67YLFUEHjC1Qri9htrL4W5fnj7OIdzcwttvmGEuGOuYOFA98RcnR0jSL
Nyqq5u/eILCh2MiKiELfsBjRv/WckpboJ+gzO1btduECvdBGjsIcjjHiIzPwNSGxnX3G6zG9OiWq
hXP2Jh0Ril7rGbajit90p+gJpDpuLee/aOh0BUXbYYLU0YIXK8bskgMir7D6cfu5oWDKwYH6/YRR
tFjIhRzFsqwjtmaxUnGTZzxsWGazk+uFfHXl7w==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 7248)
`pragma protect data_block
bdHyn+EBCbRdb4/O5X/MAmzGqEk23nukpX/XlrePmO6Hoa5arik7mKH0LyskIOu+SZhpG/YUQlnu
iJxKviZ5lg3iRG3GYtjjmvnXuW85AkD2ZIhW52m0c2bivIw+AZUGkALBgYR9TFrN+O8KmVp1DAD+
qofGK/9HCbOIdiCB8z4y74B75J1w4pdiIX9sYwhOb5/7EdJAvGUdX5uxvfD77nfRWR/EE876b/Zl
CuKkEnnPZ62tzncGWvB9Ewrbv3flKWbcRshgfq6TE41gKiyvoPv3K0+jJuQsSDuTy38pA0AxLh7c
57I87Lmq8P7eyehDxMlu7BGsOnMjR54vvjzGumkfKKee+z09BPFcN6qif8dWl22Zu/+ebuGRDv1a
lFmSZNjB9H+eQmTxjuiW6Jx4TMI15N8E2/BrvWqMZOC4BAgE73GcRt+PV2Q/JYlOUvynxR21jHfb
7p9UilqR4cxUfY6PZIj7JjpnwbePa4SBXiKK6uMRyMRuQUOPiRiuy6Q+tg3RQz8hWYtC17P88gRI
BBaw0QV22RWyCd0sB/b/Wq5+6eU19Joe/u92qYxIy8Oi4x1KEfv00C87S91ybybn1g0ng//TaiED
12wb1nEv+3PN0XUqeGbL3Otay69EXMVzxOgX6NJwg161jXaDLN/DnIJxvnboOBJjGeHG8wQbfHlL
0C6oZEmMGOCKRFX9s7gUG7xTIcdLG1PxTuDZ6hMdkeND53/UcUmuZxQ35bL5VnwH4rtUH1G/FSlF
kpy+Ai5cc7T0AHjEE2o+OQB1//uzqYKkulzEvvSU5cg75F9uEB6fGQ+BWmd2/0RPbCGiDZXp7UJx
D28RBmElgA3RFxgzOdHNEwK34M83GRf3H946/qvUQMQocKkP3wau8Z4r9qzKxhUG6D9A2BYsZV2M
H/0Al8X+HNyH8XbopbWE+2Z0B7q79427GEGKaAlH1/v7zsr5IzFNF1xSbIqE95dpmmVW2EUEGB/X
U7nLV06y1QgXqq6mzurjZ9EtJXEIJyxYodFjE+lF+iZKKNb/Wm42WMeB06MSuwwQuLmey1CA0tbd
7nlY382S7fxGA2cEgX9mOb19MfIt+d63RYG6kKEKnWKbyKtGENde+zAmnlgnb1ZafQX3Yp92X7dP
wDGYa94xYb70jqX7mKVwn2/vc7m4Ya24WgUxBhJByBkwl+rEychnsl1G2eRnuGPbnGfUNn74deNj
vvfozVKFL3vU5sx9spybHl0coXtpvn8lqm/79ghF3WnAi71rseXpqAvlkLBH5CTxgpIqyBUSwSFa
hR8Q2Qg94xJGQIqkRaz6cF0Fp3fp1V+ubqNIjnbgU5RMWyL2GJkI0gS0AuTxPuzYSmrTrL3HRSpp
xlukSzHA6Ejmws9J4Y8XnbZtO+Zpqle2Nqx1geueh9FV+Qg1nl6eXAOB46ZnrTEeMUXJBYC+RNaC
MLWei2hGLOlaAojnfsIT8d1b8cCdSeEMRT6OUJUuZm+f5hC1LVRc2G9W9XskM9QMJHPqvS8BO1VA
QhG3ggo+LRzRitIjMy4rUpvKuvwpg1BkJGQKeMvCBA3Bj0Wlj/ihQUEISLSbpj2Snzkd4LY6eFWf
mM9whnXWQRTPmJjepGUTvUirQtMZHh/ZZjS+DxU7CY2w+GRjsAsvyhpcUm1F8hjc+jQ69tT0MBij
Ur02Ijfy7WGH9ehohfcWaJYXsb2yJWkMkr9e0MOLJG6ya5ZPjvfM9BsoJ3wrTF4dE6QEkQSyrEcx
1lQYQ7MQoKQ33kqTf9cvdxzJ2yrhJVkurK/dRDFWtOLZF61+/8iY05YKvbExl8Trp+WApcJlS1YS
qtHp/KIlgC3aJtssxUnUsCsS4ezI8i2di9dznFBADRxpt2Ru7tdJhZjyy2PeIIZ2pQBmkqCOOjVz
7+zhBggP7i9vEOd9ojrjSN8EkpzAEeGivarAPyWD31wcVBSeU9wddncJkubK40KFZYqoC1h2BHgX
dNL/+42bhxC+6Zagz3/WglUGcge/Apu1NcsFCtbyNdmdVMFiiPQ+FjkfuTI8s5EfEfL3e0lLIcOx
XAkfgf30+/b6R2XN059EaimTuzVtP71S5JEGXclFL5aAnqYVVgT9+TXbW6U5DyCeJGvTFwHg3VAg
CfAG/ALXUtLuwg663ThMIBNHm2IEwP+TE3lS5STFGq/pkrPcqgW4EbGjldIauF/Zp+bHslro8Y0E
4mVK2tvjbxTxNgNYHhyIkRRb1Ifq1Sge/hmrriyWKJR2zALFMUwHm8JJ0T5otNoCfi0mgMplJmAK
7p8BrJ1RgT8qomA/Rw5x28nV/SWA91YVTmzAY4WMBlhcNcehJ5/voP0wn43puxde+vgeH0o5vHN1
YORBcQsS9QNrg9RB60tTd3OhSbGjGVpaxPHpaDY48a0RZKR18lYIhBIA5wNCTP0PLgIsezmUbPj+
H1wb4/ory6FKBNfW0gWhTXgFmgHsIRKbJ3oswz/135+4Q/mpuzf/luoES2R3e7w0TmWq6NgiddXn
0Bg09ar1P1/D7Fqkry3uwgGnG9iFKX0BXL8IHZ/2A3d7NMG7OJLM13+/S23hUfIT6UUHirePOXwA
YVKEi6WtaBgNEu2SibKyab51Ai313WR8XX+s9ouVrq+dWGzo61UE8A6xSwQqbazToyOrNsRdVvpp
o/nSuOFnU5Ybigkb+3NW0Rz3FMX6/LFBt1J4bqKBsLIZLFJIgj+7p/hTQBeoi5KkPcRuoAv5wFnC
o5mpd6DkyISOhZSD6f2VnE20lcDA7sf9PpYM8BVZUvbFeHgVDbaCiAa1dpiNIZluPrIRKtL1Q9QH
T0C3yZZK+PCt4lAQDKvAj/L7mTpvEZ1y118/oTeHoHgkQ0r3XmJfMu7gJ2i86YaIw/dBIabe+XE+
VT3lFr1t3Qdjqn/m4+y7LgXjI3ez5JIR4NIu+f+9PXXKf93x507zO07apTFb/dgfaG9r3MdSe4hY
Ortm+6n71QOH/HD3Y6uzVWtZTkc5l59x8IeqG8bDiFEqDfeDzo/axGhFQNFqgOjlO/2wvPSA1rMH
1cbYkvC+bXXdpMJZ1YOg2OsN/thx3yNUanx+p7amBNw3k5OzdYpjIHwww64qT9jci7C3DY74SyA2
R1bfFB/R4s0B4clg133z1QHqNG2HUG7Pb+zNWQO02SH36oJr9m1oD7p9hEIgovdnRdJV7DPQ1Udu
B8m6yshlfqUyc76fiV+lfQiO1gjANOASnwyuhGStr1HVpzrhV4pcQQHASwwVS0iJ0CesuV4Db9K1
ODZRo34DWmUkFv5h3QhVWXaEEsxuCOdcN/vS9kYqGyOoJ4vl34BLeW5C0EbVhnzBBgoP7BfD2kEb
sbEOz0Ixih0jUVpflWnORYTB/XtpXpCTCLrfqzZs1GC/LXtN4M6YEAMg96AtzR3TC/v2Ul4OKlYK
L+IrFl1NVE1A/XFZ21ebCljgAunefzdaY059dGTR1/TSdSnFheqU7NrluDubh7zF/6/ltYK+LwP5
iVirABP/YYJcjCfGjfqFA5yDfIpW9JxBbCwM9y5FZU4POcoCb1IFHWjmAyG1cDG3yl42P2NVg4IN
9lcjpS6irEvbQXOhXp36mQaBnwtGmHodbowHDNtlmXJmDrFwQQxdzJknqe4GBAuHDBQVud5o85ri
OKZoBbRZ+1aV2q1+zoY2MFt6Kdh6R7kxx4RIUgGGaXOF4kGT4eh7LBYd0WLsIrSLfdA3KEglnQiI
J9FslN6WH7RIt9XfNX0k9m1My+B3cFQS7LkeVKUj36n1JtRKy7AxnoQ1MOm5emW0ktSvsJ6m9tNt
dWdzhLD4d0EcmoMcggS07DPk9YhEhjGU0a3EAzp2x+w0O1v5pAx5ObdgltF80GLfdloppHrR+7Y2
aUoXl/lOUgND4Y/MICKgsgDFErO6c3gRWgyNzZYxpcvJwjspJyfzuq1gaiUjfuTJ3ipJ033BBclT
eZff6QRL/9y5PNCEyvqRle5gV7HJSwkqywGSnGNTKUTW6sgb5Fp7H4/FlqSg7S/C9hkZBKM0zIIn
cX4+BGzSKhMDRBODikDv2HE6GalPApk064rKYuviy55Ia7skLi30hPe+WAhYaNsLXzwsnpifmGCk
Q7DDO1jUS6VaX5XKymqe/84Rz0dgesKhBkSV3HZSJKt8ZJhBeC4kAx67cxuLbdpcAMTZod9tueRX
w/Pwn7ndwIIEfX9UzNmF4j1VxmF/k0Xl5eTX18Iqm5aYQBO8zNZX58C1mKAyZEJZAGBECtNxLWBR
lIBzrn61/kE5PNb3sYS1l77t6OJly6fvInQdLi+9Bmx5Rur0EWym80gSUUH0NN3NkBvOZ2pDPRPk
6F5KALS3Seto8x/MnI9PcLQLLfNDELGezEYldFdN9ZnO9iDUaFOnMZHTNRTs9wbecw9OdJz40kPp
6beOjcIVPu913CFOYUTHiocnRV037xM3ZcMH52IgVL4Nr1vbZjxvPHWiRX9B+68qm9oSsWYvIT24
QQNceyknqoXVtz3/82k5GnTLZJJBlqgPbi8Zn4Hf3uKpicguy402snQXbXvs8uepNjIfgSEIg6Pf
fOAiYfsiKI2gGWnznL5SXPBgIrqgJfr2kI8V20xlbJNguFgkOXycY4X82pBaNReunf1Ss+ftJWPc
kf2q6zLORAi0v7Y5l43hGc/JUq9No1qnkpCMV2Mzj5E8x/x3u4VBS14fVCQNTQTUTktikGon7iZy
5+TWjmhvFobY+DQjzwgLJA3aNt/5E9KQ2ZLvPLPwopKldivSWJn+E7mjsMIMuqzP3RwDrSj/OpUi
3wdag3Xpkh2Ju6AwZYZrM66hveDlzl8V0uURIQDVtUmTxUTK0hP+3w+Jk9VXd+xnzbOf2lpt7Ewj
csk6SAVCpTbKXRFaMSYQWM9e1pNkVlLfoNRJCuYzAhRXcD06FLg85a8BV22qgyOGEJigX7E4r7IX
BD3yYuDFR4udio6Y7EGYb22o8HvagEWoKcUG++dGALZBn8Ae404AKFaqPPiMYTEMHQaI3trgFPdR
NFP6A9lBsCowbZ0hWxTM/G/9SVa9oe0t5T8TntGh7fcYzIH003yykVGmgVZXAPTW6bvDRj0gUKXE
lpTelkOezkaH/akD5z4rUxFC6xfF4pNdbsmlAzzIjAAa8LxKxkNW1rWnqB0eOjSUzsfIIHwIyTJL
wop3LKvCUrNw7yvW0cPovQn3MrHEi2WkRf9tgkk8IN/gEL03KjU6nQ64HJfX0SYWkW7yzd+WJPkD
9KV+s4OyyyGJCDH1ery7JugqMsRUJ7xZFl/Jeq+o1ueUesH/SvPqqaNowtbQdiI8219plVMlxRTj
NUInxLM1GJ153rHxtMT2UNAj4fesPf1QUAs0sLUnA0fpzHwsxmzPTzL3TUbXn85bMZ5OYzQVIu1r
5jTeXzHFR0yEBu78wXiVK+Ua/0sMdSkKQdWyjYIeK2YRMxLfrTgkD9B2+Nkv9AkPLjLh8L1wnmvF
y0PfSQ+UBkYq5gVKBw5aYUjzGEgnvNJhb0uVTS7+BXxnRE5wDSF4a+A1IRD2oJsCPP+jPESrI3zS
sU+MraShh1f4r4kXSiDwj/rmPvVFavIS4a7c7cEK1aNXWQej6fZ/Z9zN/pgZR+7zaqUqy9a7GpPQ
yPmNYn88MsWjhgLSuEHxOPJgq2JoX9ZpFBosDKPiLTJiK1qQ2NDcZHagLragj3/s+tnT37ZU4/IW
XT7Khcp5Pq34Xq617KV1R4XycJastLPG47YmXwCslc16usDgXUZ5GNlo9IroVt4J0+L1wS2F/HUY
eRv8P94eMlDUjFFnDAUHuaqK51bC1QO9Wv3q6hMUNbTaKTN3X6wiQA8UBOaMBbXd7WGkN72yCiFM
1H36zJIZgV5Av6IJdQGjj7/PR8EZCgBhBLQ1POtZv0IjqmgdIvmgO76JD6K5nS624aLdV9C+Bmv8
S/uS/1EAbsbA1jfg/5TxAqKJPijm6qKjkPXD36tmOqDa3HCtxNPnWNBw/Q1SbgqqdT9hahfE48dr
seagua7rvHv7j1bj2tDPAO68lXgU3eZl3aKEp76SrXvWVNBydKeKcxeHKDcQXt0jCrqpRDT3sM6M
pqIXz9M9s+9WULk4Ih5h1xT+p7mGoZHbxLnbJWiVupyISri9jmTS7asx3x5rV98XLAPeUgyNagio
GJbulY1uxJNrqKXH/bFN55K8CFy/K94whj42vtU4lzf/Rw1N8hMGhndozCvRMpjGTgt8Ny9BvpvH
g10yjxj/z/EZp1ri0OoPve3tZ7CrIpayOJAqIMYNsozVmfWbo1ytAya9Agr4M6sHE+ik4spWrw5q
PLtmzi+quZ6INXeVniIYY7IXN7PV+UO2KYDkBJXVhmKlsqHVQB28v8inxk8nFy0ztzxjchKAQmfk
pJ3OHzMu7+ZzaVZZowFtOnAWuT01DZHcXdFLFdnC8UnDGzNJxB4tgxpOF/XRQVq4OAk7+vr5wugz
Ofaymm8CuShtB/oO9PjZbT8JCZ3pfv9P96e15TnJwSCaGVMqEJsKKRsdvYs2me/kz2xSJEDTkOqH
y34cBZCbZsRWU5Eh4b5X0m8IKFCEsihaB3+ZxOPxHFDCYn3ECCC9Yis6GNR7IA/WBG6fPQ3mkdWh
gFQS3UwWsQoeOfb02TnvyNIiS9FrQ1m9aLo1R13JOb+TeyqLS5hAQea5qMTMQ79RDBvwN85VEjhQ
lz8cbZ6A48UKCQyxqO9ebSuYETUCKh+5OZM+41a8pZOj7jeKDRg/pGVk48ZISNV4h+1ZX9XnzmNU
5PdbMOdehArvTGXyJkTacEvpZrNhVEW8g1B7aHURiQY38jM4o1eAOoXl+8qTL/qSbRQeyOXt2Qs3
/qtj1j8406OzK7rIyelw0TK4LKKGPJkuA5Tp/i4N3Ztyrk5ZcxfFaEk7aMiy974T3B7I8IHC7w8J
/qy9kw/8/DuDgJU/JwDIDn4G9TKDM62drOAiXNL+qVBgeMm8pkxJzY5GlRqmNfJ/FKAmv/GzP6IK
LMiQSssIiEoKyDzLPWPFSHsG47sbA7S8+XTOHKd8aLy6oj0w45LawKw9XOKAii3bpNaas05fie/a
O6llV8mWiDOXj59Y4I1Im1EvGPJleBtJLn+jyjkrqDGJT9RijJ/a92Xghi+Dsx5SgjmfVq4lU2Zg
4KABFqwO+wTnWak9nMSCeiYv/OQOuneUI3Qq4QxGJdWkt84qsY/2jkm/dXvbpZYYQnU5uhI7Tn6Q
0KzuyShg+AYGqt2MSwI/6g0aKZG6wFT/XjfAppyoEr8BC9SwYMVrgUhcXvuyrwnUs5xVKNvJmd6F
xpKZAsT9pmBnAZ4XmqzN7YZgL7+FTjYN9no6PQ3+2owocO/g6zjSn5eN+MuXcThW7kJu7JodddPa
Wb1OtYp4UDO8ZKlMWGELYkvHqaNT8ycd9nthG3UdXFYfWWZzjEY6ZkFwxMEAd4dIG/6Ulwor4jbT
nmyjlKw/8kMAGmv+/fe5Te79H8pUeR8HOWGXCKQ1b4gCgE+ITBHAQUTZoHySBun5fIevwMmyy+Bg
r43Y7feEGv/C4WR0AI6GRX+GhK7gczVPEKoitv3KjbWZhinGGMWIY2ndcM0kOQQMfjLozvpSBj7n
hclQCi1kL9I39Fi0Y2ENMvVBz0Ksk3fwfgDktgW8bAqmV3+6uwWRUi0Vn0qkMD03yJWHxrDMRqzI
sfXLXn2/GMkmUyynkHN5oEqGLlgLiNeBg8G92KzBesZMkQltMWRQxFDjxuIEUpdnHlhGFyk3ENN4
Y7C/5ddfs/ixtLji/jBgjwKRBuFvYH8Bnx+MCHZwfngPOcpAHMCxFS+kvvANjwRoqE1VoRC8jul1
+TjXoJ5+1e6CCDDT4XVxpABPmNAVzAAp/TW/xxzVxCWkliPt+gV4oofguM5F3H1knep1i0XL+dLZ
XsBjE2itVo2OutJuQQAvp1OSpZENiSWjRBH+qNssBikOXNi8/AgiVvk1ula/M8vijPQQdcWSAJMP
ASR3UlVuM0yZYKo9mSn3ceQJ7dcK2NJq+vjorrmtmXUQY7fvgabPdoScLeQaonN8h4X16N9NM/Ww
1wIUIQPf491Z/qhaW1bKqdW3Ae52UbwSfJdgWB6C10U6t3XTG7OnmR0DM+af47qqjQhujwCqC9us
qovzLvN3OHx/ijOSxe7VDWmXCGskCs3HedoWht9oU4GStUjRpQdfv30UYoWDGmh5Ohfpqp7fc3iN
2EMeH8yzl/veN9wqrl5vNTJUM2eCmfYPts9ER841TtjXT5SIwfI8DKZgoVxWPdrdOUAc1NYOzSuv
sbD3v55cnuS2Jx6zCbII7BY3EQ8ZoLiSqv/jMfGSMj9kIHduwC6QUbUy0afi+s0KxtzhpAcnVwOH
OMK3kNjQlj5RwJht59Ve9WGExkisOmSbTwdYdriNhKYF6TckiwNjmVU3xQEn3+iNMoJCMyGKmh1B
ZzqICkkm+FmzJ7ZyGsoGIPnTyV77v+5Q1RFUcXhetwWbtEgFosclGACgJjtOwU0Obikz59bdierT
Pnz+Oj+lkMCArDUcJFnxA2XBGZhdf4AjfCLCBThtvVhO73LhpxFS5nEW+JWXn+L7/q5aXlkPmMQP
X6/HHaKvy9VVSd9tSajvVaJUcCm4NRo1w5j36OayKaQIlPril0EWgB51Da2c8/xv3TXfs2IooTsR
6Xsk+SK0GwINhX6+rZi9SsMf82cVqH65S++whr6xnya75uoCXVe2hq7RfmSfsqjsNpfSGzvNpZNS
cXndkc1mJ81okyJtSXArkm9vVVHQks/gxR3CeHkGhNNJIezhXTI9sInG3aRFqCtqnwqfYjSzXNpH
OcnCPAM0fi51dEF1VsxpB5synnU5zI8oEvgQfwGhlDZM1xm60XKXsxi9HACE3SnpqI7fGFKvCenJ
AxfCDaGedrVNSfnceplV+ai6Cl7Q3SYTim9f5Dl5lRK++JieoirlXpMaJEy1gJXXdB5rhgljZh3C
YGfIfIlJQeEUoIuwivIOGZAxVPniLYPno3QPOX1lDwOS4OsjMDhNOgc88OxVzqzwgjycIuaghJKl
LdEH0V312U+sMaLb4MvuVsK9iaFBT50RttCt5PsLgT5B6MTiNC2VZYyemV6YN5BZe6KL0tYUNMU1
wcvbzK30Ex27JHcMoS8/+67EJkTJ4pQaRJkoEiiplFBrUiTa63ESAahwmN7vuPDQ0GcvQPO4I/5U
K1Ofa44xfDtIB/DJhS7is3809mIII7lEokevWT1E98QavJgC2DB4IxmKZHrfQ6H11pj3emA5ElEN
brkzywH7Rek0dg+Zra2n5mIYcyUHTxeF10qiSbvXPbiO8pm/+0ybWbOS7EG2HmefwQFePjhq9BeQ
zUUiLtee5tKT2/WTJmZQ0iKDxe/vTpBEN56qf56l8eRx8E6kpw6ooSpEQF1jKpgbmZFHadcx7cNl
OkIvL046JGGie6Ee71ofpP8wG2O/a2sqWwTI83iClZqEhCNbW4ahtiNcC8xomYoXnoneAzu4wMxv
35tm7fNxgnkMYnHI0VKjosbjOpPdN0FluY+kAnUNe3Or/SVhexRzT7CnoLlASbZliSI59TxBeb2g
G2C5rZVCCCcFCfTTRUUoTmQIB/g4JaEcIixb9rSgHdLO8Aggo4zyeR6mBPJPvFOznDM9BWDW7cv4
CEWNIFjbxqY/
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
