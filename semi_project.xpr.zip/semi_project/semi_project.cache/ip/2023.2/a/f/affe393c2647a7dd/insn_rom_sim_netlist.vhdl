-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2023.2 (win64) Build 4029153 Fri Oct 13 20:14:34 MDT 2023
-- Date        : Thu Jun 18 21:53:23 2026
-- Host        : DESKTOP-D1BDUE3 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ insn_rom_sim_netlist.vhdl
-- Design      : insn_rom
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcsg324-1
-- --------------------------------------------------------------------------------
`protect begin_protected
`protect version = 1
`protect encrypt_agent = "XILINX"
`protect encrypt_agent_info = "Xilinx Encryption Tool 2023.2"
`protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`protect key_block
uwBH4JaTzmENPjp1VK18+NmHqz3idKCCPayqakkK6bYDVk0JtRfycJYNxbcnLmlw5yuLTcDXBBKk
FqBPE2n7wWKg9tfz2Y8PrWAvnbsIFMfxBK8sfWUf8PPnz8vUwwMHjbXUWcgCgvtygj/TbB+jcZ8Z
CjYnBZ8tNdKOO1iDLpQ=

`protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
Ff7o4KDFniNgPFT3cDZtw4HhiKzFbOFtLXtuci0MZhgQ8oZ15BcuowAfxUJXngU8JkWI9cbWKkG8
h/PODwnWEt4eK4VDKRk6Hw3QkZiKAa1N3QupC8D5bR7vJ/+RhJwSayz9t2JpdZaEhKgCgqTcX6oZ
4fCEOmSTUWVob+DXV4UfaMyfVm5VI0wxZ7q0mjFx+pdkt56PuNREX9kH4a9Ma1P0sYo8XaTpANLa
JC6eXOuUQlp40M9F/NL1Xajpys0YfGx8AveMAFEyfRmHZs+NbXmny/79vednrm+FhwtS9LveegmF
NZW9jiiR+9Igeraaz+QXPc6JO/nCDTr4Fuwusg==

`protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`protect key_block
enb/INzHPP7GNdz8dyyqgVCJiMs9JXcjMywZXhzPersGm0A258UOUwtOqcF1rO7lnrKwTeWbNFVN
dO3BxXBpzGnYWUqDda208CYV9hTWFhfySQdX58qn1Z8QY5G7KniMCVjaGuPPCfToPOOdbAxR9XUp
XbMr0vrZKWxz8nBhGYc=

`protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
RKZNANfa63/n14iwmSxsB/UeV76BNqjEiYgjlZ2LdFWOArCv6D+jhC4sjGMiaz8GJ8J5kQeiWB0Y
e1+zdHflgzODs6eVC82MlEcfgP0vdDIBn0PP8rVDg5O31eQuJ7n5zn4XJu+vzjpkvJIHKrktAsP4
jg+LRxcTOu0dILImk7Vwgyuwhi8OxNN+jBVbLVxdNj0l5aQMgRZlU/8FVh3u958SH7z/fHnwGaOw
P8QgNv0ZZblWvpxa8TJIwlgVb9354a0eyD9XsKy5VfuUG03nmputxNzUuIUmGtBGCqx+4D4pyCch
j/ixD5iiKRmeKD1/RtGzxmrJap7SAHMuzic1Hw==

`protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
OQMD0qoDy+4W8+jfTV63GDTwmjWvJILCTofeYJTZqWc2KhrzQXwVMW48dTyIriC6bA4bmXD5BwcB
W2gGbVUvY1Y1+wEFEwYIC0LiPrJO0DhpM1JhP2vkxnTEwaODiEp5x3XqHgsiys0I2/9mE4z4Hlbl
jzftQ/8sVSYokhMp9eaIHk3HNCSBllv90qeBfH3fOdVI2gA1r/22PktttbkyKji24r7jM5o4aMIc
Sp6u0DCnD2cSPCuCuMW3A9sFRuTKbXiLAeeymFIAXHKYQgWXXOqmbKHrk4GviHQyz31C9d+hm6dh
RMtaCyWnhqo3QE/QxP0TsYk3CgkjDCU+KK/ozA==

`protect key_keyowner="Xilinx", key_keyname="xilinxt_2022_10", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
uV1eryjGs1SHbpKIAk5r3BY2SLKX9RlfGw6gbw/UtzBYt4U7vTBIy+x767ojEcmbGLos8kr8vilV
cnNOnsbu7vOAUIe+1PgpaPaCkv2OTPXaE0tfps6+Q6D3zB6j2a2FE1gRIPOniwAdlIn69jL2tuWD
M2BN1efQhi0lZHuKtTgzBOVXIg+zbTiH2k2kHWThOi6WayoBEny+g88wRi6pUBeB6aW3ezFYNmsl
zeOY9xmt+UhRMcr87DCcZdmjsIk6VrsIKF60y93pM0IoQ56iWpQ2OKZK+Ng9qC+pNHBEYEhiMQFb
kUesHtcFOIS7Ok6S9O9SMgf7lMQFOh9w0L31UA==

`protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
GM2VxmvaiVBg1DsqOLewt6rcWtfH/Gj1QS7fUSMudF5qJ2fn+TXd8kcCwwrxdcXNXjoVi2As5jmL
yw1/NZreemrkS1YCJJDxmnE8CW2q9/4N4a79kApF1VfD5XdpaULhVn+Eb+jXCQFG+GEEOvnPb0Me
bbfRkfc0DAIWgtG2D81EQ28mg7KAWtsDpdUCi+BKdIAj8RXoTiQbFbiBeT7EiRIrz2PQF9nhQBfF
FjlrCNwDP4hRQJQeZcf/1Pl8SFyKGQb6iVF+VhhCVCunL7VBmzaCOW/gowPM7hRM2dvzmxcgeKfs
dZx/fy2rk1iokUi+3B+Jc6CycMWbHu8EfCh7iQ==

`protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`protect key_block
NSZoNMCco4gpYPcg8pb9mtee1JxEWDcDzt6wnS0LeSPMi2upLvQXnSQKMvJGGOKStJOcu1eu7x33
4Xa3ApbjbfZ+lgs1PYlyY4V+B2Lio1EEo1uzZVWFrVFvmknOZwj6Gcmj5N/osaiqKaeIw7NTTbyX
HNHOabVsQJ540qnP4u/nzS/h/AQcm0PFLadGZtHJZEzyQDSSdghD/y/OLprdBcInfQDwAxQuJpCy
ExX4lD2WMrCkymNBS9NMH0vYh4kvpYKRO/oHuGcOZVg0p8vfMmz/BJDHuxTcS3FpLT0WxGVcmUIk
cuqKQFiVwwgnW9AfYkbsMrwfl9po2pofaAY2JC5ZTMyO1qEfSu4fxTRJNnDRvW65KkMdJhZFa36p
82hcDlaYvBowndZfMc42Sxt+ZULFDTFN0HT50iteAG1yEvJ9jKBiJla+kDQJB0VD0kj4+k8aBug3
uPKVykvf1/Uaw8NoW591pML42qlh8v1RzAm6aDnPRdsDaCc5Dq9QDPuE

`protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
oRNld8VrAuP/xHUguZzkh8+wROOItnvw1FQUP5KHjxeh8nudEYH2PGefTPsV73QyEruJanGifjCR
m8XHiIxqAY9fk4CAm+2n67YLFUEHjC1Qri9htrL4W5fnj7OIdzcwttvmGEuGOuYOFA98RcnR0jSL
Nyqq5u/eILCh2MiKiELfsBjRv/WckpboJ+gzO1btduECvdBGjsIcjjHiIzPwNSGxnX3G6zG9OiWq
hXP2Jh0Ril7rGbajit90p+gJpDpuLee/aOh0BUXbYYLU0YIXK8bskgMir7D6cfu5oWDKwYH6/YRR
tFjIhRzFsqwjtmaxUnGTZzxsWGazk+uFfHXl7w==

`protect data_method = "AES128-CBC"
`protect encoding = (enctype = "BASE64", line_length = 76, bytes = 12320)
`protect data_block
cSSokenUEYafvgoLGGNOuQPyve+eY+r1+2G8nvFQgvJ+pMX2bYkosYNaQkd2EbGY8nEmSboHQ5Vk
0H6eGfcScip8z37oTghPRXb92+yuKDEMZtdZLcEkMIv1NwDaCUJS//VRZGY/I+JfCj5TiYXL64Ja
PVJrWCWEsBuznVdvpwnTnmw6zuMqCHjoVae78w3ffN/AcFVtYaZK3ZEea9sQEkd6+LhU0pK7EaIl
eb7X+KV/c5K2EcWjjX1Lx8ml48ap7G3YMxJgRc8i8q9/fjcG0vevHtJEeMxjcMFkfeiHi1l8hTeX
TBR/GtldrOyJp3Ut1hBkHnWmH3S4a+bOJUCXDjoB4rqU0aqf924j57iGHWnT6X/x2VhzX2GrTY/G
xZwuT0j9o9PRQAw4VTULCbNod1PvLC5q+dhX1gK3mdsh2ZrGyKBS9ecSpBzCvAs+PxzF8YWitEg1
T3q44C5G3Ad+sUSKsJ/velXqQobffzxi/7WYU/bYH2aNf6kdJgjPA/RR459bU/CndaRsPiDfcJpy
XgrA9a/2F2tBl+WE1rTR/Vskfq+QAyUCHJTlU+wVlYzQ4IGLsxOiX3ElOM3h+EgaCI2XQm7dREIb
4X/Iyj5CCcx6keLiRGUl99PAae0t0tl7WRzd4Pi7N5kWIgDEt2l8cbNwcNkOc3/zB0moUqU9Cd2w
DJChth6JF9BBaThBdhOSAU6mNSEyxc5ZBcwQIMO2LqzJUZP2+y20Ye1ZDd5MxJ/dAsUchKXb2dXv
zOuFBnQgnPWby/4oDiVJfzMPBBEUiojiHofX8flj/K4bZeBNpohrZAvdUN3Lz1CzdU1m1kBw8F7/
9oHQiT44YsABQFSPbvhoS023hhSiRZSzL6X6NReKd0OaZDjP503ZiXhgXCN35j+Tp9S0WKtdzKg6
PODG7N0LiKpHW3XIqqaqKVdSg0MymfvkHLZI6X1wx1nCtp9n8c3GBx2RHjG5f7m9YysCwwcA5UAK
d55bOWdsrY2wQ/RUw3q4NZQ/YuojojZGCwvB9q3nTg4OgHhISe80k63i+eyS/EjvrNPFcl6/iUdA
Imh+mHxXRroknoRtYpCU6dDisMZITur0pu2mrmzwwW78+kFQjHrDoYppG/6ZWJIMtWJFUoyMJLbV
9+oqkGr28IRuKoeH1ubaQ5gR/ARAtm76mx/McC05xywdxAPrGefwcd5tRnp83ogaNEdp2KzGsQBk
oiavekbcdJt5pOf1+/d32Lj9MsMgbBIzkHOnxES0R+ai2sOsbx+2iYi6LqGaxaNM9kDKl0vFQnDn
zKfPzye3JhIxdOFWOPUoDdM2nrcGSp5jb7EQhjHYfWxuP2h+kwoDyDFSAmz/OCDlMqBeufuu2r4F
dFgcpC7/nd56aEfZchqu3As2HAPIU00VOQ/MAAsV6Ez0jwGBwXxDSTnbUsJzD+IWDt72c4uxDlf5
tYK+nxsoUcR2zq1nS269YIIAbnA1kub7NQnO6CEhbnpxzA5MEnZUxpHQaEN5P/U5Y6WuykzOXWfZ
EW43N5ySFr0DEcNxG8qGFFC02jSfZ5u+Q4dDQQzrsUD8wYCa0seYU6UF88W3fm+Le8uWlMirTvhT
thbDBkZgKNO+wDURa/70TQh+LPxHlmGNU4khXV/LwfI39WLBYiIBKyADm+pQXuedD5ctaiBtiGZZ
FpnGOcwssLrq8iAp4gOzZudPLnpOkcVMJJVmMNANH5xl/1lSHeY8hAYXh+RCoZyEOPHy0Tcs/eOG
Y7jGSUFDfdAWA9FIqY9dRH0VlZF8ULNd8204oXxO1msFxKXGly4CCvcGpBMknwL7x17z+yzrpr2T
hlSXoDwdG/LZfWYwR1XkDMivPg8LSCuNeSYLnmZW0uYPBRYRtTYYvLQCtTYicXvQWharQpy6AVGI
KbJoVsS5k2HYRuNXYTNxRakXA0BVbA2IzrKKtzuH7mlVa4soQm/ucwew9PcuzDnYkFXccOBFhquv
1xxIT54DRNw5YK3E4id6HQQcGBLTIAY81NibZm8SHX1bxwRdhOC1qBt9aXni9v7vF5UwoBmPyblG
YwDnhShavtVB3kcZFPxRNuAxBEaK1DSE2lmsaYFx0Rr2YwULcDDsfVUtDdOqIVlZGPzHTiggYRmt
h3ftWGJCgAWvim3KWnGVbd20J3GKx6cNjrHrH12Gs76DsyHa2FPBwVAugjslygt6APgtDe18r5M2
LEZn+B9HbnV/y6dTL83dn70zgk2SZoYRHlmVCvjSsmOrJOO7z+JHZXxhEEkfIcD99PC8Hk1TEnfU
YEP+Kd1OdROWEHmX4e/8wEIEzrOZqQSeD6LApihe2hiZ5Echg+rPPzV7tIZqLYWL/mRpysJ5vun0
NqqtHncVnrNWxnI4CC3yX8SlT0GvX+UA+cqIaq/cZI2WCCgYjBDWURWIXKxe0wUP+cw1F9GhqZTi
KByAvgbC4cGTZzE4iCLePjmkLCT4CYy0isIi9cx06q5ZJxWc2SCvKeW0MR+K7lPr6WZ2dF4rp5XF
+IanybCIQIuytTZh5l3FxQ9BJpCD8IvwDZkOnaY+Ql3OkiNSUd9VoV1aiIDUym7w/x6KgDc81del
0KsVRjjUKTTIFSdVDiqYJ27apVpX+QfZTJ/KTwBp7mW0XmDIjjAfO8B3xjTClIPSWIzMpJUF/Dms
M/ZjBrkFxcZlZ5J46L4x1XUiIASruyBhlCnN10ugdyqQBRzDay0JeP6hH2ljcKTR53PZTGy+LOtT
juECCmlEK+e9RWZHYyuBloyclD0Qh7SjbpFBA6E53+XRKTlv9h3Oz1SUjmqJwK5GoL1VAcle7uNv
cLIjqo65ahLmfQIfYz+D5oB9MOjqNa6HIK13PbpEXA/HIg1dGV9aHroJc15Fm2wwCWD+a/6JW6N8
YFbzOmUB73Zu2Sep6fyl0LSk1RB8epFUGcRZ5R4vZBgggR78O/2iqcPYm0C31th9vYv9PBZ9V9Z+
PIms9FUzo/F4OfDPYweKFVqFxjg2RU9g9abZj40NCfEri4gWydjnKOwqdQNbQR8/1BZnn0cJwOCy
gbyVTltBXOTbyJ6wYUbVrq9mY504MUeq6dpjrSdbERWV+hn+xh55JCQacy4P1fBo7KTG5xRB8VYl
Y3xkrVGO1nS2DD0OND3qNfQTO1ye532Y2QpAV9kWTT9tb8mnQ9DGthep3/U4aRYOFjuKeYk7ZI5F
H04qq1kxXUKNiBSgiyNoSHWeb6ptLSyeTyYQqTXzRxg7bPPfksusYmdELckxgvfNx4e6MZ+gQ+eY
94N+Mi5eJ3DGOM3o84zD/w3zr9bMXO2tzfXBc1/6XIhbwzbjzKDvr6JDFY7KZ9AIkjTWuIK2sUME
wwfiJo2kQWFxwKNJYMJ8P7wxSEgr+7EhFoUmrK9Ab+9zFLPa0kLDedIGlysS/gWhasmLgBCvXwFi
S6qmBOheH5RVYsTVFZCcKtk6H9v8nVzXmTSoYUkbDrzDLuA/ewaQsts52QEwVOYSs60urYOMlc3k
ytTaKYpIajK5WthZVcInIYVYizE6piDTaWA2ZKbrY46MLnYzrIlE7EmNSyt7YNWaNQ1MOo1iIhKi
a82aTj2jQeRsBn+ncYP9C7Dxt32WALGrxbTs53shRt5idS8oonUlzWk3c+S5JGpNIzn9P9fEMcYI
Kq7t1DC2OHV/Zaf9Mm180aJuUNi0O+alT8Tate2MhEldV62NzcxzAFPxWPu9BpDJgTmvHhw1ih4b
vUbcSdPfPQKy/iCYLJJkxXb/X++dODx7fwf26+jvSnMeMIwdD8ci3o8BPrB9dT6598NY13n+U7Gy
F5u6SV79fQkDm+uKmpJEQHQdht6y3Y7oxorUW4F9oqXgINc+T8MG/BuQycLn6ruSsSybYYg7WkTP
7vF4/3/CYx6uj4lISj+GRSVuBpinfnt6AdNbi8cZUzqJ19qYyWufdRWikVuXH+rS4HZJES4FwHzg
eFwtrX8Hw6p0oF7AUaToC6tseW/2uqkTpx1bxIQElHmo7b0g4FgrPAVWcIcEYTtv5jTe6P/+9Yzb
2YSKvh3DG3H82W9dq8IGUdLeP187M+vpRroJpIwf8m2SgmA11bRYYhNzqZ3JLSPMrJeNcjCtVnUR
AjpSPYFUarsQiI7S+fuLWXV1yqsCX+yTNa8VkpUapRbuNM7zz+puIUX95zfyA2LPMT1DV0SS/OWO
yOdrYelqzlIeRo+5r2WWwdOrnyi8Q/RnlRO3bj+ICA+cadyv3daJnbVuRJHuDdJ4Dgmdt1hI82VE
4eqqLv1N3o8QHGc3O+JpRGGLz+iX7raiKLbh+Olb1Fdf8GZPiyWQlru1oA6+VMJ9u1Cm5WEI/VKH
xCq95JBFwQuJ4FGb/SNXPAENJtxXTjFoPW6/rR9Gc4x2ooQDeOaXzOfk/Ft9ur/FsdgplsoMj9SN
Af/2XryU/ep1OUeKLimnFzot2p150Xb5/fhVxZ0pnnoaelv4ppBitWRrTtHjj4t+JsQxXbudCckR
d/Z+VtUBQTgq7QC18ezX3t2JqWoqys5Hn+AbuLNcrmWnweBwuzrp3I0Xh/yb4Jb399XSzVtB67px
NpMv/2cbAZUAQWeCw23S+1EYL/DGL0Cn+aeuKl8xk5jXeJhkGfk4hn2w0nCZbfXtsBmYUASxdxMv
fpAjC5lnUeJ/IrZ6B5jsyi0P2gpzPXpQhr85q4qPeSot5OMc8QCACbWXFO2tf5XMNUW86ha1/Ffz
eIMQsZrsW33DHoE8aAj8rjKhHFMYFdOzjF4fRmKJjlvozkKw6/ejMlLarHUC2EIGg7V1mr/KsWQK
E+UpfpD7sOAM4BG4iKUM+9Y6sIENfAv3v3rLnJz/G92pLQ1yoy/jBJ7FG/c0bZx5cmnI15I1m1eb
xKoqgS+jdbCkKx58vnRs9b577C1pVzMW3pnsJaie8oufs1HMdg1Hm7uszPiL1mVY6V9Q0TiKAhr0
N/sJeHRs3gRmnehU4E5gfx2HXiX3RhhiLe1AeV90ju+nu3dT0/vk2403FI+g9Vs/Fnr7tgVzA7RL
vo/SUZJ2XY1fDy78mNFevCiqLCexct2j2Z9jaZfjmI4R/37rTcdEVi6QhmxeTIcD39qeztdDoJQI
k8y7btMPBX4c8n1wBQ2IvaN19qbD26B+rvcYvXKklncqxVmOwwt+kz2Kd2htvTFPmNJA74uyQVAK
9GBh3T12j/xmTzgdqoyocRdLsHMRtmO2CJviAi+3B4PX3EdvCsXc9rxvUKiL3ZypgidShwnXdH+Y
KrQdzsrF6eKNij5ZaDzL4pvTaWhk3CyZC4nf8foisPJGVj3BRIm8wK3/w+5QFu4Lu06+etrqJ+ul
jqOXtivvXctfzedCoQEbpcOaq1IgNWvPeAHOOkuOIUvZrsLdfz3NHpQBiIfkHhmA3ssXI+Sm/G5A
UzjE47rRRA+jBREdGpQ6nLpzLqUnZPZ9Gy/Pe7KAPimGNKfWAS5bWQS0kdLZmxlDhgLCujq4Vpu0
0Rmu8gmiX4idnRhrIfkgQ88gORFnf4wENl1Sjhx9WWPllK80jWn71aNtTvpTxaTE8y4Z4aUbMHHG
4Ey0G14qpAcaW9OqMEjYMmlfX9QmHxaSQbneR6PKDNyPVtapAClmoJLBIrWtU1GvT9wQQlyh28rw
YPA5emyqwdUHRYP0JrgDV9vWXxUD2EDPjMhwjWM/F+B3AIJW6cUIv7TA4BTobEVuHyP1q2R4lsXX
OXluhJyJSyj3pWClwfuzIEwq3IbJ9FEaq9wisMrzRXmCQ0oLj/HSd/WUTD+gmEGbdGuwWEM50l1u
/G26rElaZijvbgbIhNveYKfiA3SVRNoqwN1rI/j0BVpHoJFo87SHHO3QmU+N877j6eOEKmvhFknv
m1VR1t3PFq9VxYctcLVFXM3G+68o/l6xBebH9AQhU9V4PfbUYC78p+p0y2WICQ10IqzKAgiWJtaZ
DqiknwWygxKNBoUgDmbi7c8v7FL37Dr3TwrFS+3YQLSrXQwMsSYG3vFHE49tE2nAUoc0/dAqD98G
28jrt2Q84V11cSEhACk9XLrNFQ6mJzmj4wPRnefbiR1z7Sfi9s7HiwuJ13bEPHxd48u3KIJ6sWmf
ZK3sorpT9AbRXgyxhMvhRk5Uc30jWbkY5L+mhIG7AiJ+HW6ueZLMB+L1M4KTTBEtyBqOFNBQ/zwE
m6tKGLtSPSyIFt2g05l7vprnbZnuXqoZiklRhJjtYE9jw2bl2lGS+1BxUWIvpaRtl7u8BPgaZfve
J/V8AdvjW0g2btaVQM1A42GqwAiZrvqaM5nVxLyXGpXO1ZJwfI8YU4EVh3I2QOAk+X19DsD1oU6r
9QuuXnadVBpg56HkonR1LXDOGWkdYmRxp3uH6SQB/7z1PmDKKFWnpbFP9umK30pN6F752ov4Mlxm
biglJUv9jTq8EZcLtEv969zFnhbEl1/x3eegNZqto/H/KXBdYnjFb+/4BDxFGQn+0I5iKICdLI92
zhO+rDUR516vZnlmrWJObLqGvRrLmhkA/TpT58OxABzcsNY+rw3mefqkxjh5Fmc7+G18dKjBR4/h
MCzZG/1xp4KCr7DxgdQEN5/36tprnje4dPTy4IpF6FpHKTzInaMxbB4ZB/ju0pS8PMtQXPbneDwg
NfMqjo+iZtGgNFerVW38TSDlYfJJSooF+ioNjq2hktEEGNAF+Z3pqnL8Nwxh130AyGVRYSKQhjmL
DTA0tqZ+egAg3xf+SmSJjF4f5G+A6B32CDmfFUUuo5QnTZCEd1X9TYtIVPPUIzLqcp0TlM3RfJjz
GJSYka1XGGckOc/Lj98xA6jj5FNwd8aiqqhU0+3lztwcCmJsOCv5R4UWo9DM9NbK//vRmwCQnU9V
w6MWhM2TJdM0UtfyAyo8scDZMygDDAQpgqMm75JKi6ArUh4gCZ5cGOPe6Dccc4jpSUbOj0a/07Dw
IoQqK4zhM05Kj7kfFI+QNFov+O0RI5SffQY350i0onaoj/9wlLhqUtIwPi3OwI7y3/c/2iTGAzv9
7bkq/uNxm1/l5uBwntfEEFNZswpQKPSBs6gkIj7/D28hdBy81wDwLqQzBtbee3ZIwhTHOJW6e+p8
AAgQkfnWTpSanvFMo/u74PTeCDfKL8CqCLo6gB2dS+LeZQbm5RU9diN8rfUDlSQYAgZvPJV3zq5X
+ugYwDE6XF1O+VF1WEaWjDWBXlccVzvtlg9nE8/1L7ckUEYSc+RChM/Nv9b/Laytr+DCJLRHL2ip
P50DdgJWZIlmqVLaUlJYIOSDO4mpVjbeqTwIJ0UeZ4qIFp0J/88Pm8NrgQq5Y5UHulPGj6iUy8nU
UHbM5S9H8mw3L8DZTHlUafav5AEXbwuhzZdPUAvtdN92RqS1vDz6BbGP0+Pu4tgBN5UF3Cjsunfd
FnJCXlmvOKrzWqF2u0crt06Pmh4l14NCNcwUOIjADgYaeexKwkMEUJ7c14HcnK2n5xar9WE/iUGv
T+uYPcPr5WySdSWhHNh9kTlAMcO7u6Cpn/nqoPjQ1s+1KhUWqV2sypu0DUgmWxoQPthyCYizX5Hg
C2J1UzxybnyHTjk2gxOekhBdRFQ1mt/VghVpqob/Ssk471NWNQ4R+sAtx4fqAQQOLIn5Dh4Po4N1
rpzAqP80hh9NToH4C0H87GUE4OKKE4YkVe4kzflDwN8frTteYdVXjIeRfSBXdguy3pn0t+JaMx4h
0APx67TO7IPu/AV/9x9fCXiKj/yIfgMoVnVx0Gz+ucdZD2ubMBiiv+T6rcJNEDWeHZcW7HkPAqcx
pcwTCG2JKo2PdzRoSOmkti3vSNFvO8tE8qkCDYrlKJg9AF6jreAYYUjYNTZ8sV15QOLVQ1mvcGpW
pfMj9xiL2CksOXhtj/QP/2DyiJ4w/bSHBKm0Qg8lVfuctb0hoKVqAIrU7HK5KOSZCKMZnePpEG1u
Yzj1JeWPVzEfvWlxrsGri2Qcjc9r1H3MWus2l165Axl0ZKve1bgjpHdEULLdAkE+x5Nod2FBgCZS
nQ4FIfKi8PuxlxfX+PDNCavvlZ9GhHZ5TOADtdlbxgZAlbQJAWt6/eD2+YElh4NbgppN8kOwSOgK
aqWAhp7CAF3zjRWwMmwu0sIIvq8VV+hgKaCliyoSUePAYgzqJzxDVu5WGHcvBq+AZeYVM36m/fJB
PQMvZwOUubFwgl5FLR1MMVCofo9IOu0zUYmbkeRoKXnEkBHRv8qLbskK9Tikkbp0SYWuLNpMGvhH
o5zB5c5kTEeqnL4geIly2mN+grEJHuFooCmOrkrnV2W5KHWyWK8mTQApARtef8xEjRiXjZRXPvG8
hQotMAr4CSeIBrokarMjfXQHXl9qOlGL7eDJgRD5MuAmuuRzCELgIvh5iJ3SIlE0tbCfwjFxvHUz
J/PlR7BhUSg8eBcrGQRFF4AtxHbglcrpsU3/zEwaLniYGvxb4i99XjsG2IMJMCmCCMTTtIKyy9Kb
1X8gbtK01N7IPLlZs8cv+ue6zXoUlXswUvknP1zmTcQXz7AvRDqzw6mZuEelGDvDGe5UdFrSLpcD
MejjApjWUgh0T9DHqnZY26+ctvc28m3QFnZr8Tud+Fs3A2bI2U2V51VFe9Ngti/t7xBo2RvmqW2R
9Dy9z7RwapJq8jbk0TD1jdP3Ty91KGE1k89osW1TN2TjwPAZINby9eeZpJv2hY9aO9QAaXQY4YoP
h+srHd+oVxcn9xPRBBVUx0gK2UPx1mByq56JrxKID++uJXqwUaibJloMvoV1EpjN7aTVvxPfyksj
od32DwSiOewx9syw662RrZOvhTtbjiEW+xWaWkmkyZcd7qanWhbpnTti/1bcMX4BRAHo0pJdrayK
ZeCi68EUtjOrrjawUVHBBoftQPr/9S26wuJQM4+VdTBX6mJu0anVzT+ilJFaTcBFeNheV9hhGoUS
3MsZsMyMHWC9y2pJq4+m6UPSBUr+CZ2yZTCU1K61qed+ovmbsr1vTiW1S9613V1uwug9VCIl31Tt
htB2GvBpcg2jX0vT9GNGCJUGeFULuo8o5LJmJb/aDjO0E0m1JtfSf7wEtQouoOmlw6FyEW+0eGLs
JRe8G6Q0CKaFNpd+cRBxcOtq2zogfvxFCX8fbq556LfLh+yXNaoTeCmqgbmK6sYBZG3k90zn++u6
b1gXljNTZzgd497+lno61neg1QNma7Tq0+acvqjcxCCIPrqo9IzekbtdtEOENyhhT5Ns8t3Negcx
jpJr6RMb0odG+gdj10Q8L1DjdxbGXPZi/GAY3/xdCAVZtwCYW62pRWWiRwhaChOJUjbMBu55LoQ0
s87QQVSOO+xorPaTHCsC3PXBfnTJvc82+1btjwJEGvYCHHefkdSCJRln19POWw1Yd4kQkGsY8syL
wqa+7GaGj8fpJo9Ed9H/NEuxqRvyJJJylZ5ZOKIhz9UK9t7knkn1xhwW7zPeHTZSmz51UNhSc41c
xO0OY+wHHlH5A6AFNxnWV/0BxFhBqUFzEbB4OL+k0krgOFrjy5RtW3X3zphWE5ObofyMKvRE0zKh
McReLMawx0iq9BV5KfSrfwoOY3IKnc247bxrbBiY7Ah6FpdjGM49iJ5WhJJ0Wm2yXe+RgU7sii5r
MX0r1WUdGhWQzl5nVwr1rnC9MbRzRx79KxddkRrDUFYOzYL8clDInsSz5HV9WTEZTA567y0ZHKt0
u1uQ8GBDt+29QswEY/rs2JfzvQcIGEhgNrfVVPAdtUeYyCj767Cs9kCokhy3WNdfhRT4JtlFFCPg
RTDxdbsH78xP/K56jwvxZUoVkXc30BppQ1uolANTpohlDw08Uvffa7swASfZsICSnlE9ImEMYwe8
dm1pX5fRrxuJVMnIyitvH/vbvlvoIJm/jCmGtrXH9S6mYKTmzGyi5MxvqvcExF8VyMUykHUUtmkg
6J6Ws9YV87MS3ZRHdVw8j3mufUFzTscdor5RJP8UNiO9XfZZftxrW2dcf+qx8qzr5cWMfB3pYUDi
L1CUdRo2mfioXnvgs+9X/rksIFuTDRUo4RHOK6+yfAp+6jGBcYI85LOXv71YPNdvQiW29Zm34/6B
Y8+HYrhQ3a5qRuXLSpcHNuydczypMt0FIYcIMbwIO/oDPapHOVuSpl/IfXKNL7fC2G/IWIwkj7eK
10enSXhR1OjJW+8oF9Vifz49ZUbuCshLmn1FM0J0Zk4JDaOkOIk1VVhG9F2cye/QrZdoZFijK76c
pNMy9l/lgNNSU1/SrjMPiUN2GbCLv10OuQCFyusaCQSxZtMoiIPjaJZbr7DiqJOyu8wNndeCnUwx
LeObXvvzIJoqhJGWjMPUk89WJIx7EyPbw/Qp+LQUPbkFGy0vny/StHQxBoF9r5yv47nv3apZsKTt
2Vgm7td/CI13PBDjdEIZt2iEBE0PLsk/dnKT7ONInTGcoX/iQN7UOudZxqYS5aAg+yIHL5x1GkQ/
1bOywd6M6Z7+/QCEze2foSBevFusbQ7/km+h52fZUouQPA17nqB7IY9uJamYQ9B1iRQq/4I+ZeJ6
1z9lz5oh5eCSTnPwtE73GGnLrnJ2SuBl1ZESFVuiiO2UjFBCg5CNJUSd7btWjguuhldSPT45mGxL
QaeUi4BFRKZJiMf8+xuYJW3EP0krkFp2eka/Uka6FcYadyQFIPVUHYDbmaZeXC15uatOW+80uwaS
CQnyM1oyMhuQkCWn430nyCxckLHznHxQFSgJqyN9xVuqX4efWJkA7yud6yejUX7qbeMPic/8EUAy
aQxTbrKGz6JXGps3lS9/KWfjIg9tY0aO+dXjZyI/3RUvdvBSaeNhVDgrDsCLK4zlhlkDbOLJUMik
ZcjdzZsIZkCPoWwNTubP/mrcMJ6MCuHboJBKaKciKHShPaZEsLUS9S7b1KcerGikQmj2rKUzRGTM
ab9mfKzI697ak1ZWTGb3iwTVxU17RAojgx0eI3V6OlE0FQ17paNiyEbBxbcnvrw20xVKjcVnjItu
E9zPeq0W4vrtmusvmFl5KcZihuQtnJi3FdcbR5gutOnu7FpvT8xX14V7L2cuod4qhG7RjTZ24v37
2OckipovdiyxWkEMIYUNcbNIUSsCgvIHAlfbtYfT0gelMJZ60rX2Urjad48GibtWKOyhMCCvX56O
LmaUIOz6qkxNZCbSHpszhYMLhj6AlhW8e+HWCIffMcGJvbFZKSH2ZtETqf4ING+qe8ZMq8kSUOrH
smkbefyV6uATzsmROCYVj5P1fnzj2TuVYG0qKc1qlnLlVKl8ihxWzDJOoSYFCmtxmxBO6o5nnNEG
DpBpj8heaNpHRb0ylcluOYtVv+9cswzB1NK4j4nmm5b2zN0iznU6J5r7OCtHF24ISPUTrGjKLa/2
Le93yxfmcUQ9REdf+v4DQPFRmXe7CiYEHJ+iSN9z7OaUUWFztcqBhXPE1OcBZ9TAGSKeOHS/tNO6
Wr7LRhzeC3Wyi5Pq+RumIffjSbk3NbdkuqLu4dwhtIa4jIyfaSkc2SglLmMWDF0upfwUMPQVmuxR
6WkjsC4SYnqNVfxSF9H3DA+vD6XBvJwbGrTQ+iloNrKFGgpX/EcqC45Y/XQn9ukmV3BU+zcOCXjB
nDMnjlRZTbFr0s/ZkjJ8rbAZSEABFlKPqNaLk9zVnVVbbsEWfKybix+G3oUt1s2PUqO8Nus9+tlh
m1ZZD3wVAAqpAkIidvEoB3QRXYi1bJMEg32CbYXySNTRA7HdpplL/bBXPP/zvOFDQ3/MtmPPwcEx
Q47cc9nef+eDuzZTy0oNAtHX70jjTMJ0lTM2fIyjLaFWLKwv4LqyPSvkINwXuUKBShh4yyipFUIX
vr5YZmgOQ/8ROFV23zccUXWuMEZUEGvRbXQqcCe4MTJyyNxdLHn6Jv3nt8h+h2TGJmJNcddZw2Bo
+0bonUtHsb4GF+1yDaA3NPstZHx91yfhXmTNolPIcejwNqZDm0yNDO1K/71DmtzvG9BgjCj79wI5
SaoNYOjXogx++oa+9X+MLH9R/fhYGD2eUtVF4JOjwdcrRlGm6IZaMOuMJ2CDCa0NsU5rQMxjdjl4
ZXGXYGIghlfgLTTzcU/GgE3pMDjkV88OPfqhIKr4r+Q6PvYY90vn7+0/j9Qp8jEc1dyM3tEyjUL/
mHdSGfBPqXiYNoE5bSWjj6nO3DlIC/EnGKOnYO/1F4REgFLOpllcjeFKHWD+KM7gbA3Eg2qUhD5O
JTKoIrkbVMAAoWu378gYPphvns0Qhz3outfA8Cl6IiWp858AZrOHIDTFg2LvkdOzy2NfS5HyBT3h
KM+4OJ/7knglH0zcXXH7U4f/NROcIjeheosz2j3W6E6xSzIaRDLV3kEaRtHBKIbmdpU1x96/GSea
OpmToyoXrlHbJul08iWL7aw4jl2MLwJekJf+pW3M58Q7IJRgvmppUeFv62LBygIGkV9RkLxE+nts
ZT4dJhutQcIpmEcl09Nheamix009U8hphYIDgtlWJkFgNIELI9Ukpk+ukwkTPVdHUwMDj6wZASkn
FZneJ4JDr7Cpw/inEkBW9GwvHXzLOkOgCfHBEZc6Ui2tbFTdhryoX0ToIHascizT6TpMOLGJgOgl
XNf/HdOI+E+ZY2SwlRAPUkEhgFfvW/WPGj6b+SXSQ8YXBqNx4bapa8a1auYbeFETfnduZ/9UgZWK
8whQpWZ2zR9mhsIqpy01gaZXxZAyEEUmScxZkpPQBC6NCnnh0z+DLM2bbRLo/9qqP9SrArXl94ni
n9yuBzLqjRDUGyzR1pt2vt7MnjmAE/5WjeBnxIDIothGdbHRVdArk/Z7dQyti761QjcbW8Hu85DH
hmjHscD2Nh5B5BuqsZkEjSi4RPnlw+Laoa0XFt21JbpxK6mqgSM/Byz4erohzIGipOp3zlgBj5nd
/6cJrpHZokdww9SErmKT9wDxhTuHCFWvIo8FIVak1ULl4sGqKQ+fscHDSVHP41I7Xn8sY4ueHXfn
u0REjwbfL5zvHJqAPCn5ZOec9XbgloLxAvoPLhmp6oAviC+4BYxlxtO1ywIuuMSuiEOMQ9OqwL5s
vMzoaAHlsMflPxwiTtbPEkaT/9zo6LX1r5JD8SeYE8DS1RPk6TVKxrXG69saBKgZzg0aOYQGiSsz
jEfMawxeiIO7t0quVHX9FXx5tmIO+7tiaWzcHzcGGgxfjOXO7pKwslguXeCM5Xk6V6eNEXLK/fqu
VB0YrRfOpR7oKr17LfMNO3GDFD1gvH+b7nX6jOck2jCIGrNtISQSBxcBpVH1ZU3dxbL5FqjwvXyW
Rk8KFTFnr0Rrmxbxf9NZ2OLFyIIm8WkcTNC1Mc2gQtSiglDrI74PgDtV3hwmUhELYJ27t9Ub3cF8
9m5AV/tf77oIAlzJUrFWJeCyRV4Q5z2fr6a2b8pWjhfx3ymXA8SvUGzbapyDCyKlKJ6zTnb459id
GR1BLlOU52ZgJe8tfGstf5mi8gdt0qAFJoRjLp0oq5qqSevy5idD4rJiXOYCCWHvQr0/MnEhf4e3
QOGjp9CLNu+6ByMenK6iF5h6y5c0Gsc2gxrduiGdKRiH3CVBRgm+kHxgB2qV3lrmryvLrgiHw70j
wgoOjHl+GKo/2qtmouAsD9LdQNVCft2s+L6ChmN3dH5DNgFWRWl5at3GgsWu+brmlPxCEcb1LP1H
K9eULC9hs/1nf2YDMq6LJVIdAKfpy/xEoGf7qdA8ycITtm4tjSw5qlMyFCorSldiLfY3hpDPzXku
LWvRPC0Lsl9mp073MYvAWZa2jEnJ+NT1FNbL1pCRUB/PzwrStUniTCNppzg8He4d0zzzN8BG/XB2
Kh7OCYcD/ExtTl3JWAKM3UB3JQkAFL36MDBn1VXOhUSMynu+GzXxc2hL3dLFRIwARhw3p9c36iaQ
+oRx/wAhGee+0ucZZUChK961m/Iq1F228phdlSebKAmuyUFcS0GYT4YXi8Adt8ozROP4ALhR4H0k
dZFfGaBVpveB7+h5EaZvBf1BDtyIo6NjsqNmooHVY9e1zBXUB2VoeP66xQYEGCBCcM0Pokv5mGk5
AyQy6yVAM3a/Igw/+PmRnn5z98cTErdIqlN0nUqYDI2aqBnN6u3a6Oju+zW0WAqOTuBFJUMdRKwg
1iqv6KN8+0fLC9Cj4sGLK1vpgZsKKlLXFs90fteFFMby9LhRAf77lCLiin+718qEzzxdT41D0kvl
5sNyuVL5Ve7kylGUWBrrFdwzcKv2Dm7hZneeq4sCW/HFjDFqZ/xsjK7rvzfy1JBd4GcKDgwo5Vaq
LXg5g44+8IfPR4J8uex3zSM7Gw9NZMTOfsrEJuQySnKBEsAtWlRCDBMr4xKS3TdqHYNgR2ms1qkO
d2ITmdzrUfgSXI1UjEuTaHKoif7A4cXAx9PDAUb5fujN4gUq+ay99y3kMMqAGnrk5MFfw2D3JWnR
y17xKa4Bd43NvprHJdmyneoIIWQdQyiuhc2juiDzK2qH+YdBdBXXcGMM9ZpB543FIEVpSt4ujXoe
jnwzQBnc3eQl2IrdIv+f3Tf3KNEhX04I5UsQD78NzF+Ex9eNSBHwNwk3b2e1hwGbgwwkXXNifwpP
Ke9Zmr9oLKOWvUHPZFj4MdVRKuaox8W+llAealPxua8BIGiBEuRuuYFli659I3zdyoeqLIflVHev
Qpwi3lbsA7fNBamQiyKlQSmfzyqt6czzVVBvZFPBqHb8VuangEYWDiJJ3QLwNsvtSTrmu6jYVrom
wORGAJcfOO5CDAjXWEwapJdQig7LYBDuNPocxrJBIbQpuFQkKx5n8hztX5cm4DH45Abm0gEhkT6S
qsOf5cyQkngfPuNhsW5KcxcLMPvfCudrDKlTvbOUQdIlv/g2h/s6uXcXHkShPhWFu5Oiw7dRfS5g
mdOX/PYduvU8AFueY5LZTUKfzP8+SGPwqZRz2cgW6kEl8EjJR6knEL35M/scWc82Lro5Xmu0Yjvs
SZus2GNY6Hwb22GKOC6snm2avikDjQlNLxfhmojuMMeQfDpfqGXTZvUXOM0cBF2ra5n2hLQktWan
If7maYEwOCAY9tNo/svL/6RBAFHbLKHyRrDtPNqTimRVFbZ80+Xqv1JDQMuUAD5rX889JcyjwYMg
0FUA39mUlkENAm6jrImsTObKwc216uxqpl3I6HkeIGw7erGO4ZKY8tX/0WllVL95uH6b6LDvcw5s
ILxPkStXypBtF60n61n9xguUEW6nr6BBE+JAChrfaGchY41CczmE/Pd4BMW0SxDqCfuxhg/eL8kH
XvVyJffLfbFETx3zuOGFeNXdTZcj0H0TmS+crWcmU1xWum/TFbHl8a3/bPcF4lTgTD4t8khh96AN
n+QDjUqNqFDRKKymGw8L6eOVf39Rozwzje94GiYWw1c3z/kB991zKooV6zr1an5P2q1XIodyrhcB
Ga1O9lJdLVSh25KKxPBEE9k0kacHea4zA8Z+CqLBAl/wkMNswnC/QreF6k/h/comUOI6n/svfQNA
z/avlYPmoAdLZNnz9Z9epi4JpkfodETxNKHxDtsTJfJzq6l/+UPAW5NwoUFcuJd8anSPO1EXWEu6
Poqbli6bATSjPnvw9e0s/XTiLiUH8paKLy090/5c8IBGg9S1txtauyGvHLxPZeLZwRJFIzW8AAEs
EyaRI8cJwl1g9NKB+7T3mNcKZzENsYaRYU3xqayXKLsnI/7aYOT4YGgShlhGpZZRyojLaiV52W7n
0dkRs+yBObzEHoJ33j02vNGGGEDO6eDjGxCaTbnWEqwrk+7xwxbJYUmUI2ybNnNtdaKwD/uB8W9h
ho5I1C8E2CdVdXOU7s4X2qZPlonKV5peuTJrG4l+jFvGY+Dgg2NOAOIOq4pHvhjZKea36fvEwzoF
OjaRqrSf/mLDMSgpei3imoSuEXbjt0pHRxxSgIMCW0IBVPK+lcSTfMG1e04dnq95yoTtjjyGtKpA
zQHQ0bOPIqdNX8+k68/Hg9cMv6zLYJqYqnHoLKvIInib7gZopzxBY+q1+Gj3H+wKkGdqD14K3NpC
VOzvJktr/+tC8CxsZC+mQ9of43LUd/xrxGb4hbY8Dx+Pzqs4D3y3Bmr5w8zPaVcEwKrfQ00WxqmG
qsaUjVonPYCYFAYM9OquBJzQCro2dZe8fpQ9C9ww5vtRHj4VyigD+gRLmS0E/9Obgr+rwWmhap0R
4WTKt7Gz6IVMFVER3Z661DwIItyythgmx6FsnmCy3qmFdFQf97X2yc8SrV32xCsjB596Ncpu1lxF
EpTn8i+3o/t1CbJiqOeD21Bdk6JvJa4s0QWU5hvEJAhl9SrkeXDfLKrpcbBUlFVOTx8StDDJqOJP
zTllH/R9xjthMAt6pNdWGTCoKP/80Ayf3jEPmmRHwbpD+iaL3sbTdcSg9AWCi/zkx1Lx11+2luzE
hciNBtHfjF+l2DvyNaK7Bf0kn4RfPjbP4a3myX89nHA3Q7Kf7Pzfv6MFFfr2bu5yHg532xtsZvmQ
Di6SK4FmRZc=
`protect end_protected
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    a : in STD_LOGIC_VECTOR ( 3 downto 0 );
    spo : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "insn_rom,dist_mem_gen_v8_0_14,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "dist_mem_gen_v8_0_14,Vivado 2023.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \<const0>\ : STD_LOGIC;
  signal \^spo\ : STD_LOGIC_VECTOR ( 28 downto 0 );
  signal NLW_U0_dpo_UNCONNECTED : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal NLW_U0_qdpo_UNCONNECTED : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal NLW_U0_qspo_UNCONNECTED : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal NLW_U0_spo_UNCONNECTED : STD_LOGIC_VECTOR ( 31 downto 4 );
  attribute C_FAMILY : string;
  attribute C_FAMILY of U0 : label is "artix7";
  attribute C_HAS_D : integer;
  attribute C_HAS_D of U0 : label is 0;
  attribute C_HAS_DPO : integer;
  attribute C_HAS_DPO of U0 : label is 0;
  attribute C_HAS_DPRA : integer;
  attribute C_HAS_DPRA of U0 : label is 0;
  attribute C_HAS_I_CE : integer;
  attribute C_HAS_I_CE of U0 : label is 0;
  attribute C_HAS_QDPO : integer;
  attribute C_HAS_QDPO of U0 : label is 0;
  attribute C_HAS_QDPO_CE : integer;
  attribute C_HAS_QDPO_CE of U0 : label is 0;
  attribute C_HAS_QDPO_CLK : integer;
  attribute C_HAS_QDPO_CLK of U0 : label is 0;
  attribute C_HAS_QDPO_RST : integer;
  attribute C_HAS_QDPO_RST of U0 : label is 0;
  attribute C_HAS_QDPO_SRST : integer;
  attribute C_HAS_QDPO_SRST of U0 : label is 0;
  attribute C_HAS_WE : integer;
  attribute C_HAS_WE of U0 : label is 0;
  attribute C_MEM_TYPE : integer;
  attribute C_MEM_TYPE of U0 : label is 0;
  attribute C_PIPELINE_STAGES : integer;
  attribute C_PIPELINE_STAGES of U0 : label is 0;
  attribute C_QCE_JOINED : integer;
  attribute C_QCE_JOINED of U0 : label is 0;
  attribute C_QUALIFY_WE : integer;
  attribute C_QUALIFY_WE of U0 : label is 0;
  attribute C_REG_DPRA_INPUT : integer;
  attribute C_REG_DPRA_INPUT of U0 : label is 0;
  attribute c_addr_width : integer;
  attribute c_addr_width of U0 : label is 4;
  attribute c_default_data : string;
  attribute c_default_data of U0 : label is "0";
  attribute c_depth : integer;
  attribute c_depth of U0 : label is 16;
  attribute c_elaboration_dir : string;
  attribute c_elaboration_dir of U0 : label is "./";
  attribute c_has_clk : integer;
  attribute c_has_clk of U0 : label is 0;
  attribute c_has_qspo : integer;
  attribute c_has_qspo of U0 : label is 0;
  attribute c_has_qspo_ce : integer;
  attribute c_has_qspo_ce of U0 : label is 0;
  attribute c_has_qspo_rst : integer;
  attribute c_has_qspo_rst of U0 : label is 0;
  attribute c_has_qspo_srst : integer;
  attribute c_has_qspo_srst of U0 : label is 0;
  attribute c_has_spo : integer;
  attribute c_has_spo of U0 : label is 1;
  attribute c_mem_init_file : string;
  attribute c_mem_init_file of U0 : label is "insn_rom.mif";
  attribute c_parser_type : integer;
  attribute c_parser_type of U0 : label is 1;
  attribute c_read_mif : integer;
  attribute c_read_mif of U0 : label is 1;
  attribute c_reg_a_d_inputs : integer;
  attribute c_reg_a_d_inputs of U0 : label is 0;
  attribute c_sync_enable : integer;
  attribute c_sync_enable of U0 : label is 1;
  attribute c_width : integer;
  attribute c_width of U0 : label is 32;
  attribute is_du_within_envelope : string;
  attribute is_du_within_envelope of U0 : label is "true";
begin
  spo(31) <= \<const0>\;
  spo(30) <= \<const0>\;
  spo(29) <= \<const0>\;
  spo(28 downto 26) <= \^spo\(28 downto 26);
  spo(25) <= \<const0>\;
  spo(24) <= \<const0>\;
  spo(23) <= \<const0>\;
  spo(22) <= \^spo\(22);
  spo(21) <= \<const0>\;
  spo(20) <= \<const0>\;
  spo(19) <= \<const0>\;
  spo(18) <= \<const0>\;
  spo(17) <= \<const0>\;
  spo(16) <= \<const0>\;
  spo(15) <= \<const0>\;
  spo(14) <= \<const0>\;
  spo(13) <= \<const0>\;
  spo(12) <= \<const0>\;
  spo(11) <= \<const0>\;
  spo(10) <= \<const0>\;
  spo(9) <= \<const0>\;
  spo(8) <= \<const0>\;
  spo(7) <= \<const0>\;
  spo(6) <= \<const0>\;
  spo(5) <= \<const0>\;
  spo(4) <= \<const0>\;
  spo(3 downto 0) <= \^spo\(3 downto 0);
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_dist_mem_gen_v8_0_14
     port map (
      a(3 downto 0) => a(3 downto 0),
      clk => '0',
      d(31 downto 0) => B"00000000000000000000000000000000",
      dpo(31 downto 0) => NLW_U0_dpo_UNCONNECTED(31 downto 0),
      dpra(3 downto 0) => B"0000",
      i_ce => '1',
      qdpo(31 downto 0) => NLW_U0_qdpo_UNCONNECTED(31 downto 0),
      qdpo_ce => '1',
      qdpo_clk => '0',
      qdpo_rst => '0',
      qdpo_srst => '0',
      qspo(31 downto 0) => NLW_U0_qspo_UNCONNECTED(31 downto 0),
      qspo_ce => '1',
      qspo_rst => '0',
      qspo_srst => '0',
      spo(31 downto 29) => NLW_U0_spo_UNCONNECTED(31 downto 29),
      spo(28 downto 26) => \^spo\(28 downto 26),
      spo(25 downto 23) => NLW_U0_spo_UNCONNECTED(25 downto 23),
      spo(22) => \^spo\(22),
      spo(21 downto 4) => NLW_U0_spo_UNCONNECTED(21 downto 4),
      spo(3 downto 0) => \^spo\(3 downto 0),
      we => '0'
    );
end STRUCTURE;
