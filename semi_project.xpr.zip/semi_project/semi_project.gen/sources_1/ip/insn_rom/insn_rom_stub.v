// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2023.2 (win64) Build 4029153 Fri Oct 13 20:14:34 MDT 2023
// Date        : Thu Jun 18 21:59:32 2026
// Host        : DESKTOP-D1BDUE3 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub {d:/Project
//               Folders/Vivado_Repos/semi_project.xpr/semi_project/semi_project.gen/sources_1/ip/insn_rom/insn_rom_stub.v}
// Design      : insn_rom
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcsg324-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* x_core_info = "dist_mem_gen_v8_0_14,Vivado 2023.2" *)
module insn_rom(a, spo)
/* synthesis syn_black_box black_box_pad_pin="a[3:0],spo[31:0]" */;
  input [3:0]a;
  output [31:0]spo;
endmodule
