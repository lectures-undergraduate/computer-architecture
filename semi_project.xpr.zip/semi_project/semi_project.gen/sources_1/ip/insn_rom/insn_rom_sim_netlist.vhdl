-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2023.2 (win64) Build 4029153 Fri Oct 13 20:14:34 MDT 2023
-- Date        : Thu Jun 18 21:59:32 2026
-- Host        : DESKTOP-D1BDUE3 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim {d:/Project
--               Folders/Vivado_Repos/semi_project.xpr/semi_project/semi_project.gen/sources_1/ip/insn_rom/insn_rom_sim_netlist.vhdl}
-- Design      : insn_rom
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcsg324-1
-- --------------------------------------------------------------------------------
`protect begin_protected
`protect version = 1
`protect encrypt_agent = "XILINX"
`protect encrypt_agent_info = "Xilinx Encryption Tool 2023.2"
`protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`protect key_block
uwBH4JaTzmENPjp1VK18+NmHqz3idKCCPayqakkK6bYDVk0JtRfycJYNxbcnLmlw5yuLTcDXBBKk
FqBPE2n7wWKg9tfz2Y8PrWAvnbsIFMfxBK8sfWUf8PPnz8vUwwMHjbXUWcgCgvtygj/TbB+jcZ8Z
CjYnBZ8tNdKOO1iDLpQ=

`protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
Ff7o4KDFniNgPFT3cDZtw4HhiKzFbOFtLXtuci0MZhgQ8oZ15BcuowAfxUJXngU8JkWI9cbWKkG8
h/PODwnWEt4eK4VDKRk6Hw3QkZiKAa1N3QupC8D5bR7vJ/+RhJwSayz9t2JpdZaEhKgCgqTcX6oZ
4fCEOmSTUWVob+DXV4UfaMyfVm5VI0wxZ7q0mjFx+pdkt56PuNREX9kH4a9Ma1P0sYo8XaTpANLa
JC6eXOuUQlp40M9F/NL1Xajpys0YfGx8AveMAFEyfRmHZs+NbXmny/79vednrm+FhwtS9LveegmF
NZW9jiiR+9Igeraaz+QXPc6JO/nCDTr4Fuwusg==

`protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`protect key_block
enb/INzHPP7GNdz8dyyqgVCJiMs9JXcjMywZXhzPersGm0A258UOUwtOqcF1rO7lnrKwTeWbNFVN
dO3BxXBpzGnYWUqDda208CYV9hTWFhfySQdX58qn1Z8QY5G7KniMCVjaGuPPCfToPOOdbAxR9XUp
XbMr0vrZKWxz8nBhGYc=

`protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
RKZNANfa63/n14iwmSxsB/UeV76BNqjEiYgjlZ2LdFWOArCv6D+jhC4sjGMiaz8GJ8J5kQeiWB0Y
e1+zdHflgzODs6eVC82MlEcfgP0vdDIBn0PP8rVDg5O31eQuJ7n5zn4XJu+vzjpkvJIHKrktAsP4
jg+LRxcTOu0dILImk7Vwgyuwhi8OxNN+jBVbLVxdNj0l5aQMgRZlU/8FVh3u958SH7z/fHnwGaOw
P8QgNv0ZZblWvpxa8TJIwlgVb9354a0eyD9XsKy5VfuUG03nmputxNzUuIUmGtBGCqx+4D4pyCch
j/ixD5iiKRmeKD1/RtGzxmrJap7SAHMuzic1Hw==

`protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
OQMD0qoDy+4W8+jfTV63GDTwmjWvJILCTofeYJTZqWc2KhrzQXwVMW48dTyIriC6bA4bmXD5BwcB
W2gGbVUvY1Y1+wEFEwYIC0LiPrJO0DhpM1JhP2vkxnTEwaODiEp5x3XqHgsiys0I2/9mE4z4Hlbl
jzftQ/8sVSYokhMp9eaIHk3HNCSBllv90qeBfH3fOdVI2gA1r/22PktttbkyKji24r7jM5o4aMIc
Sp6u0DCnD2cSPCuCuMW3A9sFRuTKbXiLAeeymFIAXHKYQgWXXOqmbKHrk4GviHQyz31C9d+hm6dh
RMtaCyWnhqo3QE/QxP0TsYk3CgkjDCU+KK/ozA==

`protect key_keyowner="Xilinx", key_keyname="xilinxt_2022_10", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
uV1eryjGs1SHbpKIAk5r3BY2SLKX9RlfGw6gbw/UtzBYt4U7vTBIy+x767ojEcmbGLos8kr8vilV
cnNOnsbu7vOAUIe+1PgpaPaCkv2OTPXaE0tfps6+Q6D3zB6j2a2FE1gRIPOniwAdlIn69jL2tuWD
M2BN1efQhi0lZHuKtTgzBOVXIg+zbTiH2k2kHWThOi6WayoBEny+g88wRi6pUBeB6aW3ezFYNmsl
zeOY9xmt+UhRMcr87DCcZdmjsIk6VrsIKF60y93pM0IoQ56iWpQ2OKZK+Ng9qC+pNHBEYEhiMQFb
kUesHtcFOIS7Ok6S9O9SMgf7lMQFOh9w0L31UA==

`protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
GM2VxmvaiVBg1DsqOLewt6rcWtfH/Gj1QS7fUSMudF5qJ2fn+TXd8kcCwwrxdcXNXjoVi2As5jmL
yw1/NZreemrkS1YCJJDxmnE8CW2q9/4N4a79kApF1VfD5XdpaULhVn+Eb+jXCQFG+GEEOvnPb0Me
bbfRkfc0DAIWgtG2D81EQ28mg7KAWtsDpdUCi+BKdIAj8RXoTiQbFbiBeT7EiRIrz2PQF9nhQBfF
FjlrCNwDP4hRQJQeZcf/1Pl8SFyKGQb6iVF+VhhCVCunL7VBmzaCOW/gowPM7hRM2dvzmxcgeKfs
dZx/fy2rk1iokUi+3B+Jc6CycMWbHu8EfCh7iQ==

`protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`protect key_block
NSZoNMCco4gpYPcg8pb9mtee1JxEWDcDzt6wnS0LeSPMi2upLvQXnSQKMvJGGOKStJOcu1eu7x33
4Xa3ApbjbfZ+lgs1PYlyY4V+B2Lio1EEo1uzZVWFrVFvmknOZwj6Gcmj5N/osaiqKaeIw7NTTbyX
HNHOabVsQJ540qnP4u/nzS/h/AQcm0PFLadGZtHJZEzyQDSSdghD/y/OLprdBcInfQDwAxQuJpCy
ExX4lD2WMrCkymNBS9NMH0vYh4kvpYKRO/oHuGcOZVg0p8vfMmz/BJDHuxTcS3FpLT0WxGVcmUIk
cuqKQFiVwwgnW9AfYkbsMrwfl9po2pofaAY2JC5ZTMyO1qEfSu4fxTRJNnDRvW65KkMdJhZFa36p
82hcDlaYvBowndZfMc42Sxt+ZULFDTFN0HT50iteAG1yEvJ9jKBiJla+kDQJB0VD0kj4+k8aBug3
uPKVykvf1/Uaw8NoW591pML42qlh8v1RzAm6aDnPRdsDaCc5Dq9QDPuE

`protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`protect key_block
oRNld8VrAuP/xHUguZzkh8+wROOItnvw1FQUP5KHjxeh8nudEYH2PGefTPsV73QyEruJanGifjCR
m8XHiIxqAY9fk4CAm+2n67YLFUEHjC1Qri9htrL4W5fnj7OIdzcwttvmGEuGOuYOFA98RcnR0jSL
Nyqq5u/eILCh2MiKiELfsBjRv/WckpboJ+gzO1btduECvdBGjsIcjjHiIzPwNSGxnX3G6zG9OiWq
hXP2Jh0Ril7rGbajit90p+gJpDpuLee/aOh0BUXbYYLU0YIXK8bskgMir7D6cfu5oWDKwYH6/YRR
tFjIhRzFsqwjtmaxUnGTZzxsWGazk+uFfHXl7w==

`protect data_method = "AES128-CBC"
`protect encoding = (enctype = "BASE64", line_length = 76, bytes = 11216)
`protect data_block
lDoemhS2cLRwdK4uyhpYKLWUMhddj3HUpHzNECH9HyoyJrUx85fnFgqVfz9874evdD1P294MeZYK
VmFbe1yUKPFObP0MhrQmpzVh96DngOQEFmZPCc658o5RUlq6hNpI5cxWRt1UCQRPJu2obREU/XsH
1/JNqAqWka1FvKXhlRCiJE1QoMuOGIv7Kbzshf1qNxkTo0uTGN6ilpL7O7qHwEgd7F2Gw/xg83aD
T3WHUD4xNQkRcCKrsfy80YYlQy60SoOpSTNeX+iF/EOymfKiF/vkjZ0mYmBrs5Pxj0RyV+LasS+z
TydyyEehwnSPcUgPAOpcp+U5U0E1JYgcBJ+WBvJqIZqnW7b7tSLeOlhdDfPbZ/rwtbGHF/dbnlso
E8MH277yC+T3XV3cLl7K2dJDZoUUUguPkz2Of8ne6RUSDYmU3S1OL926DYKYhz1AI0p0KdIoR87D
JQS1xyAuIcTfFaVT6b8s3mAyBkq5mpiHS7x0rgeGurcnYdW6H4mRaQrf4MFBUkQUMBqhUcPMfr6J
WJC7rg+GL+dfQZ0O8YP0ZCKKIAJqdUEbeyG4yZgJ2tOAw8Qk5ihuKv7KzFbUSe0xTXrU3e/8hVcZ
6HNst0OYel3j6CUtwLbz9mUVCPP/s6v72onwSYEQza97MJ9NcamC+2fj135rw44fn1R7YCKniU6Y
uMiUW3vcJYhjbySjQR9NpCu/Udqf3cpCHPgn8Xq7QNNvXA+U8uEzHdHQjJTyWld9VM3+C4HEaalw
Xh0GsQZkvAp9xX8FUCDOe+PJTYja6aWaF358fUeYczgOarv7nc2RzZ83Idf4rK+HY9kwIRJTEdR/
stuCu8YlY5JGBnUB0t3638PdWzkwkbkPHL3X1IWk0HNvLTGDJ69oVMMdpbK0fEda8CvmBp8teWZQ
FG7EDf+RuQvcPwSKFGAsv6QxC1SxMrAyO1hfmMfJOH6EIeeBxr6p4k90M16cwVaTKLXDfWkUOlyo
FP/tvet4wizXD9rJHWak5LgPn3bO5QQg5LxH+2gQg+EWx4cfXfuQ8qCEt2z5+z8PynWIQbf6iSFz
dHqVgALqz+GV55fWRJGah7QtJCNIeGqTQd2JVobl3+IB2e+e8bhUwBPR2i0zWXTPFhfze/3HJKoI
Xzh/j2vrS80Ey8ebVujsKJKhd2xt3BuQXYIOcNnBQ5mH4R6SSlz+WjEonJrwZ6/ptfqFmiSwFyAi
AP0oQ23L36czZ3xkUnK7urlEXkaiQH1Mttf3qwoYw8O6mK2RYymNYP94df2O4tklODzNiVBY5wqv
7n4pnvkgAfsPAZQGm1XVGB/mCC9L2A9gNm1CL7vdhddf4lTp+nhhZXEdPXN9EJzqLH8XcO9xREZN
xhBez6MURDFXnNq54vl2VNOosNKkvOlxFqVn765rqZHDhwbfWPl8kK/x08RJJl4AZRzga7pueneq
B7/Avikp3VvP6Adyh8qwalZ3LLnUQHeQAg1h99TFkfxuwp71QOq9qag8BJzW3ws+43IISE++gQrP
oH/cNM+ooZNY1oDjW0DzH4tVScD31VCYtidzMtZZRkXHrM78aTsRgMROW1bPnkz47vLMRLJcTKhK
XfoCLG8lJbkw51ayVUTMIj1MyqAZMqCkHL2kJ+STmn6FcQBgg0HbFtIWLjLHSAVmjzWRHbDCSI9p
50OiUrbmTjmfnRs0b+OnvWN0A5/bQ2VGTPq32rjVGBYqJ3lImj6mBzW9DNnHcto0IeGQD/a2Okh8
FJnOubz8ROUh3oHng4Z4XtkNM4FBbs5dOScBJZkIfgsWZpHqXhz2FduFgFY9GCSe3qq70g297tOT
MrfWKzsIktOIpwsa9lq1a91T8xDRBSLliWzMWx1rk/69aUI80uzRJBG0NgKy1a2pNeUEg1abIRNK
OpaE67GbHG92vGgtRsbenzJdFD2s+lk2rlpNwVil2iwjXAwCN6epRQxmFKVYK/YYeiTo3lUy1KEZ
LE82/uRU7nSgr891h7Nmsp/eOcQyNGzUbcIOXH3uYxLHBYgI8d6gMcL1FDwsmfe9Hknlhq1J+y9t
dsecF7/mwxsqu8IBbI7FKWODGGE/zqyXtik/WflJiXgaBl00erMpneAWLW6+RyemubR22XDB4qts
Zp0MpZoxlWruAizMdObv/NrivbqMv3R7S0+K47pFHskGiLve9dJck99Tp1BraChlVP3IGcZLyJiT
YOeHF5X1Fum+HAOiAAirdiARjUpMRAaCNwzlBUjkOR/rjcsGfXVO4XIyA68zcLHOE/hQwIY7PFLF
VGWYlQHV29sFBvCwUV+qTIpnxt2haJtjXrhYGOz6t4qlBX1t5LqXtza5B1UmydA5G6bMbHsYFw47
ockoCDUjQNhDGVjXN+2bM6e/jQb0PU5mP33U19PHejwd+SdT7J0R0I/QNJkNMQCSGB4nJkbrSctK
6Q1Vza45N2Hj/3jM+g7IXR4Zp92lE+irveWdzUUB2oGoTZTq7TJmpQRoHzM4ddl7YQfK8qmiJU5c
l92exSfT0ZymLnLJz/E2+BfU0JbDYnZt0G5sryOrYhpp0S6LH5g97uqBa7fJb4jZi2H5xi7dIx3G
lI+WSHgkzAVnocdMATuu3+tEA9GRTzRuk4+aywP6SF9oBGwDZ5mVRD5ORbICIZ7tnbrvEzZOrd0k
qREB+cnY1exax6Cj6/XVkF5XztoyJJbgHB1JvxnmH4lcXqCIVPX0jZTD2qM3Wa2NX4UvR5KKqgMK
Vo0d7gNSvejp8Qs0X7T+S3p+R+cW1SoQj4uOFZffrHlnSAzK8IYRJuSVWeRMrdpSLSKPlZ46nu4X
bHeg1CtP1Iow1WsUIS6+KrSAIbKvWYvWUOD9MFCbgSuW2lnafGxUBELZ28vVaagluC0lsiTuoq/q
9irUF8EmQsHc3w/k9El/FOQGQlcNfjR8jF9C8dYX6LlMbaSsTjWrKr/6rvlC53INRVERlOR9qlgw
4V72EoKqh6V//lpw/4dur19FB/344hlgM8yct0nHOlCPhWh3GPpjd79ghyH5XTgUmmcahOdeYFwp
QVqzmh9ulSoTyEpwbugTGG1g0njkHPCMq3maApIES2Tv3JYJWs+ttnHQ6qvhNut1PIHz0Gk5Gljw
VXniop7AqpOdN/rfsaA7UYRdKmm9GEbCz1oQproqDhYYMRvNFvxf5YCKSTEzjb+5CQx+4Xqk8oVH
GV73RibK/cVBDCj2f2ayf+FF7F9RLPXE/ll2rY1i8BchPWutIBNkllNf5ce+eOzhQYPU5iVh8n6i
yneYUvjoewnIB7L64ZUWEU4+FRbiV+o6zojlyDdA15nKW7rin3XugAOFQeejjpIOUSedmaaTR3Q6
2KDHje4Te83bimg9Y0MMSsUyukCBFZO3b5FSCI+UCtYssJkOLeDTTjNjy5o8bjg20RShdVRD7BcG
oQv8va3aBpVIY+GkQ6nxw/URvAgShlnNgryMsbFtgE1/PdaZMGbZhB1Y/EnpnJfGVKEXzezJ/++k
mral5vA+KISnpo6zKXBwkgMnziUhMoC340AXcxni+V0kA3LxI7PSmEIOEwmZA9hPvzW3E+oKDAXI
q4QNA0SHzgy5zNnDmHrjqBuIQOm/hjEez4AWow+0wAfQfrIsyJcg27wQbIUxEul5ObhoqTcMBU7j
/M+dFkCI1GTS+Uj6CHC/zhSgtzACUBYWV1L5iNRtYpc3sWBn6rRGSTb5+VtL9wpqhu8CBF1IopH6
xK/IQuSuZD6qxRa3abs7ZQ1hfjBJwrtu0WUc82Q9pRv75vLd/4L/P9t/JdzJl1TpuyLeK7Nai2af
wHbzMYhDdilT+NfYDPqY49E+sA0TnHdMdwgZXVU2cebKf7BOslJyhQkV7ar/RddxQqZa3pj14iLb
8J4IrXrtfejtqn9RIpdj3Bb4WrGVZaPdoX1GylXV+GELByx5oSTqw6eLfiq6AEhBSpBJjeNeMDXA
oxJSHsudtvbJAWolbnJrqf7Jmhlb7ig7bp+jmbWaBf90kgRIqO1ZXpFWOD6BiCQH3xpYm/njbD+I
N6gWkn0aqTdgquydfw53oo53rr1th2/PKKAYm1fAmYolnUgTV5L0bOQiEjKF2U3+wTucNrCJjt9r
hdf2kzT7npslJaDFLNZG129GlUUA38nOK2mR0J9pt3IGvLJPyTYSEu47VUo/vR1QL3vhPP0injw5
GgrQsA+/pwlmtRZBNEKLV4dQovWkmuutVj3bVJLJeW38gbWuRHsAZnlxe3v8nzrDdgG5RBdQjohQ
9q4BKPE+jXlONNrUQvDFhkOk70DwRjsBeGT1CJmeuIafO/b9nn1tbkIWJdUfDzeiU9td43ZI4xat
FtkoO4yANQNXMS9/h5IiLtNVf0feeSvkc5XJqSwwpjBskCptVKsrCZkHZmEoseWJi65+ouutZopN
iJEhFUkpUO+5h/QZnD6sGNcqALXVNptgxQaAm13nAqK+9MJefTWra/weqFVTl4M/qCf9hwgHnGGM
iPz/DuTRJntLTLGnM9Zg3ixShQW7XhVBaievhw9p3idNaEAyS3dVPHNV59tBqlLcVEQJVnYtCQAa
tTuA8yWiOy1Ttnmif0JZT1lL/n+L2KVG82sTDaa6Rqi6/6qjPe75rod/xebfu2dAG3Bu0NfcsbZ+
CV9rfClxUfxAGWglGfGxakPWv9BPie7bh2nPWMNyL6Ssx7GqWSJgiXW11Ht+YVDnUsrGor0oSopg
2uiX02tWMAn4uZ7WZPRUkBTvfftkbWruiJXUlTHynyJ3SCvyBK8/yTpn8PTjl77S1DwxjUi35Yl+
2yGOwnLzyI9k1VZunKDC7A4lYPHngw8VVbyzKjfH4shMtkgwWPMcEK8isE6ZZVzTTyItSRROzUpv
vyIgfWjGwJ9nIWycKMf8NQNzrq98dvXC7ChqnjOpf/vO01yi+hV4FJA4XwOHMx3Pfc4rki9O8aar
rR0wZvyvB3uQrqNYLYCWxd3c++Kgxc7EoHmNNXknq+HvlK0Q8bXdjjVMPRyv9lazD2cO69j2rKLn
ySlhBS6tZX7NPGmJqSreJlvGp1Le5CkrvZy5sz+VnQOdrbxa490DGLfQpRtLtMtBcZqNIll0PfnC
gLuKnilO+6A5mMUz+OR6Hp2POkVC05l4T7FKbiE4Qe3Y2S//PvO1tNDcXb7pX/Q34TTEqVeFbp0b
9RO+CngTsxn7K2Ft9IrTVYn320eBV58EI5mBMdphYQ6KuOgKhnPhyCMEnozjUM6g5ivbulReNt7i
5Mqhn53D1duaJ3mLRnqP7P1G7pnLFeSxJgG53RVF49qrVDMLcEnKH7rXRf6Y4Lt/yj8tI3RnJP9G
pCmaxT1mY8lvpNR+7ABQ6KlRPR4a+JxJlM6RdSp8e8DMmEq8fXDz00G1e25/kx+smyqPduyNEwGz
7cZOkOShf2eWXG+0UnUNbjIj6V2DMmEKPgGibBP73ULG5zFF9dLgPiWOi0tkBb/G3FHhzMhgvSmp
d+rkswtbwTW2gHKUPXJvvnzs3mbZG2qVfMIPqnoKGZvy5vwOb4yz2wel/acwwwFaMqFETeFgVEes
vz+r6scpDkLtWoy7vtwMAHYSH03WlT5cNNyMAPr0XK4sHN9Qoh/mVu0VAYhPcT+8wqCZ9QCr3U5F
ANZlweAz9yYxKKYQu8vmg7+4XDWwMihuwv94AHn4/EPgIi3SiwAysvqjeprgUPNetnIcmSTrfzNj
noXlDyzcOeTyRUfJ6d/ZTXITuFsRroCeKKHdKYoNKdediUCV4SUXKYvup/Hk3rgOmpBJnuPip4Tt
2CcQVzu2spbijKSsvL0GN/PiS9MgDu0vtTU0JwFL9xRrjL7RqIZJcNK+NzUQTMm7MS0FrpDiDcOb
Ar9iwTwyW4s8i0RA2jli6JlSE+26XNTCs0tLdvT6VUkPOqjZSumm5g8iH9s3gYLtF3g/KSXByj0S
nHn3wD+2t2wUO68LQtz6EqaLtzp6OQqsHt+tg7IF+eLAwjXw80br0sUMtE5m3mVQKr0jW+X3bqH0
eFOfkCOm8W8vkr3wAYE2ltmgqqEo5WXLTCI+fehSLNAlFEYk7BJo5mq8iMP8PyMvyYc74uQvLn1I
r3HJVaOUnZ/UiXEFUhY1v2+tT74ucmCIeRJHSbxer3EowC0uTmg8OW1TwiZygeDMr0zmKQTuP3Ht
OqFBmVJIqYFg4GR/mz3G+JSpZzA/PeGFXcBqznVgrCjCNJA3oU9ljIpE/P+GV168b7B44pNDcoj7
L2qKkjV9ERTKr7JUTMTrnCv4uyQoeBqhA8UlNnQkomqMns/Im0cmCegRpHgob1co+yt0cTRj/nUv
ovUIq0QiC+P8To09e81tpSO5xiRZqyhyesOfBZWut1Z7eoSZGdCrAAPPiPSO4s7ZM5ktbhBqR6Ff
0c0bJTGvtxVbgR/p7lZa3JYS7ndAKe7oKAbWqc9IXXvl4pMysG0zPlfAC2724mazm6CrUs0Q7SXs
kbQOCZhyMBJ38wATWwLvYCdg8VRVAIGrfO2L48U44+wItJAAOEyKbfQJqHUC7TEh0Z0XZTox+xyk
SOJFAehNvt7z4W09GQiC4hoUsaYTMV0DiUj641LfviPrmCPeDW4kWew4zFLO3V0M+/CQuopCerBY
+H91VsD/36lln/P/8S7i3Ey3qVJ0dwwnRYRB4sGc8O+iBMkXNFoctQpcUJrIkOC5Y+sTSV9Fmgfn
qIASf5QqomlqyeEIdtUy7L29GqTDcyqnn6ctwBKWJ/JMwJ+JhDodr5HMHN6DM/eDfvvPgiIzn9yO
0i3iWweX0qvUtSKh1UKq7azCT2V5M5jCIvAs/xdLZxE7861CokUBj+Uh+Q0jrmXhXk5Jx4FpMDxH
LdGcnQ2lecM4oKIXHNkOAwpkHebFNV3X8sO5WBcVRFkaWbh6Vax/t3jtVA9QMp+oasXT91kcGtYB
EDp/4rCIk6N0hYaJnOAQdP0DDyrYF6o3t+zDA9e5vVu3zVHLeQNAROe9eS0OefWHB1oRh9/90vP8
HwArLfFzgeOan/cF90mrDehzQ2am0+/CBir4o9fz5IdM9XjbxshxrnxhQ9fFodqk/91SzzPgM6cC
3ERbJFwyp1XAiqAZaG1FwDeCIHIu0IAGfh9KqIVqxYXLCc0pTnL8uS5uKKZpZfpx31sqWX9TZPI4
2WeG6HYkUUzgWUwMKlXvG8UjHKW7DXTrnb6m2HeWxaIm71VqwyrZgov5nCHdusOAcAAJV7P7DIYD
4Xn2SwSMpVRmgoOlcvhKOzjirNxS5sfkac6FLoWXvb1G9HYXyYjhNxiG3p1np/UgCDN1moqKXYGf
I9cPmToAXHCFpMsOQTsJJw8S6yGm0juhY91/02NFktt9r8Nu8/ynQJwP9s+pvG8dQ7GSs76uQwGL
sq/JnjmiHbErOXrdkfIgA37IfI7EdAXZT5DJmOGuxwjqWDYORnQyhSHk6KZtqwEiDLytTxexs2Wa
ImhW/ciFRqSOjYcc9K3qWS96lG1IUo4gTViYxwH1uSiRpkZdbDJL9QaYcGR+M56Jhlv0Qf7eZAlx
/WqZH7A/CqCKepctZ/6AVVAdnSxuBm0OyWV8eg7hEjFqiJHAtw6LSUdN8EAjl2/Uuz9MBicij8n/
XFogd6406RkPpkfMqZ+PYoGt4tjYYJUWlNCjBN8fxjkcyEol7uoCSMekNvfhah4v1tv0Y2Me5HIO
XLlTphttrrnGUS6Oy0Z2TVjVl++7F74fJ3sFYg1bycDSh8uB3SZWoIQBQ2ovjyUxqq3Z43paEG19
qnW0j8Yj503G5EJ91ZTAC0zcP6QRmCqJ0Ud0EODG6/huFuptM0DVDXAO7McUqxRd3PLNnr8lfDov
6oSzt9CDv2hO5Um5qyRRuyzUdtRAChgDK3/fCVsMnctoANU1YNCmmsIUEf+x7zpXixg6EgnpbTed
eKyIinB0H8qPAKm+K7S0uYLWE3AtOjejEGT8L7vi28cqbiHn7g3cIzuGOU7aIxq13EVD96YIdnOI
poF9LqMzwclOh2cXuP5r2WkBVr0H0U/0tVU8NjP9UFvLspnzvJ7HBBVwJ9++65KG1zzeJJTzKUyn
8P4NxcbOWF8ofFB+EEq507Ow1HooO0KxyMMWsf9ZI2GhLJlQLnet5C6ElLxNaVaaLBJHH85DEjGn
+3iuA6MK8zQY9dYqpHDL3ANvz0I9OT8mXTK2N7SuZtAZW+NbJMAOZpdSx6Baa4GN/1n/WYfvEuat
CYPy9DLuyFaWdTnkrzXCx3VL6m2yU4ytK1tPHmmh4uYsPsUh9GAApGOT3es1xk8ZWPZZpBQGrnyI
bl/8MWgO6VHmQVYaedCtWzRxQhW4qx6R4kVYjrNFE9ggVWSCi4oGa8YNPyV5zMswfBldwF5oK1cU
30dJNA4BnwVTj4lYBDWiM0v2Qhy/qeJgiye8JzipMTjsMr+3moP30Wa5o90KjMXajj0ZTWlDHXOB
XacLQR7mPHKEBN3lVhKLRCF19OoW+QOV8sDaY/kwA0RfOuABhP5GPrwwWxoDND7NNu9AO1ognGt0
C+QmbfOZyu1iJE0gOmsXmtU1LomXyLZPiu45dAJLyABbXi41EzMtHa/p1rdD8AzQ9I6Fumpo2v9h
LnITeVgRqfZg9vRuZydWUi15sPVgJIbGeZlAtzH/rEcToX4NSP8M6zbcMTmy7imPwIL3Gp3pv5Dn
pXgZ/5Vx6zwIwhstLEbX7LqE56CUjVaFtZ10GBaEnC9MWXnVX3+8RzF6Yu7HE1dtqkAqUfI5eofw
a4HgK5LpQznHTsAoGULjpv+e8FPJ0mTlLZzpMS5PWyxwHgmxA6ERhrate1MVshL75AOCcjzQ8lRu
XIQAhmWw73ZeCFKC+Qqux69qJ0d1wWIgkf8T8rfrYgHVVdk9jtZoWIeZcLtLJINDlo5ELH3lfIsp
BXqIVcPn6/AeTO3cBx8ndmfMELPBHZUolh8wlIh8MAEl2ydZT7pen4ayeqBOZc7Jo1dYbF22ydN9
90XjMN6Z/+NhnzF19lCDaZW3DkIXO74+YN3Q/aM9JjftcFA/yORmsiwUxIK6ErLpMDrE3Nsqqgzi
8EN2dVC3u2Ar22dBdWT2lURNu/8020T2CgiYCYu0AQQV3dSa+3BYptS2AUUkgq/4ury8Byh+yNsY
tQ8aAExpGbe7m2DhBB9/mfDjYOuGMx0p8uflxzvUPUXBDyJFe5lpEfwQJECHn/PXAfv8U9T1x1xD
tA7pOes4z/RwuMftar+/iLMVtfnMMIjqcNxPzq8vxdt5sCGsv1q7ED2Ac4AnENuSjhyUFCuCMpR2
17rV7R9KXMClXYVH8SRiuebqqEO4j/LcBDq49O6TyMSPHDEvBgp21OovAajbLb33i5ApS4yJLchg
CCm0ToDY4+iA2wae6leWlBBrvgyicFohiMXmJkW5U1smFPPwZqns7t5nRzFjPM49S9v1h6oNphw1
+46rMD5XHAozbdXhQBUvQ8b41lwJ6oYahGSSuBVSUmU682uegoF6yPbPOwvBUcuk2aC3Y7J+ApkC
z7k/grzZA764vrYo8hf8fPHkycn3FHdq30u6SFH9wiEQy+dHkmUTx0KW6odFL64jp+k9iekDMh5C
zD4PLTy51Xb297bhP2iAzXnGd8O9AfddKgGvQXF5eXPd6lKlk+lb33xIkXuNNKvQpHfQNS/GbqEf
fDVcxK1G024GHXyDXk6PZ/KAiL6T7nIIPEIENOIRw+w2m4U3XjbEQMQ/G/6fp0C8vZQHgQkrLp01
Y4Gb49NoRD4lZLZVJHuOrIEHdXolUYcJbkgtWwXLLkgpUxGebGIeYK5qSdV6Sl+JEDM2Oh/pQE74
qikb2EzCxzc3TDktAmmpgBQqT0kQ3Ebil/Ja+X6PWqGcSssvJL/l0v5Wz+i+bPr//MJ1biPD0/VV
0kINfTYoyNLBoceKH8xKDbg6dh5j/GLhZSyvbQKLyEvzjUThlKA79XONWOIs/f1KRmUg7f00lXfT
O4CXV0P2p6pObz17y474iJGjny1ZTAR7NrlQ9sftJXamzhJ/MeDA0RudBhvo8wvQOk7W32Td1K68
TpCnuQWCdwPGVz//BfoD/Ux97OPOfG9ro9oY9bcsIsGJdhlRsDWHg3ggLcY7A1YvYdyxmTdDFtj3
O498yYWxNzRd+hV3qYEfy6w6BFnyOpYrguctMzsi5cbVTz+sE3syAD7Fvxfw10VuCOYDYSuwsTQT
Wtcp9Kl2UJjCzX4XvcPNWDPatN/lMnQaeiw8FJ37DO5yQPz8rreIn4UdL7JW8dV2FYnM9BYV/4dm
Webiz0edyjhiwrxjeLmAlMu222u8VezvkVLGHZfU8jypF2Fm40xQjYAJSTzLzb5XQRTOnRmzXojs
eMsE+9etxRS9RhaNz/tKOIyOpHfR6+sj4FPb0EJR8Tw1EVONYnPeD5T0w3PhetNEEh7MCpHuHs6r
HdAJvW6g+R8kEcM7xvzC67269ZOeqHvJl+I6fJ2t0o8Xf2sNtHBdYDDVLWSNXh93ZOYlC0XGpm/A
453IGoSJZbCRr3pQAYrHqNXY6OVugU888FSeyiABN3A0Mfy7ZwPjSbSASZIkJ9T4BExb8coLG0cK
y94mWVHS4FVcssWjQhc6Y19OcJ42uxmc8QPLfwmPY3yHSImSlpMvE0zRx1kqgzNEbm7BUi2FS3mG
1D5atussOXqCs5GpU2SQDbZycS7VFHdAFXjo2JFCHs0ZiZB3u6pf2KX26H/LSY6WDelZriXPUncI
FYUHKODC5klx/Ywqi84UDTviHrjnstbjdjq7KB/sgctQWbQe7TzVa7DpVjhs2smUPj9+ynkLpRLb
HBhERy28qUMbGIjHUXa1TUW/LiTX0BIg17oc5Qj1lhE3q+FapNEypMB6G4545qhqGx8BSSthCxMh
kutIcX+TAjjzZeisWiLATiWlDFp2VIE7Okh2u30ZQQXs6KN82ptvyQzcogLFsxWUrMoBLn0yn7x+
GjfP9wZ5IuMvuO+YgWemrTEmy/Y76l3j+nP6D/8KqWK8XV4YxQuuDrEtgNEqBXMgxpp3eBLjnGOR
lDsBVzJEVvY8T1JxHVpv+zkJtVfB6aalF1Gkp8qsWQd7nXUOQKjRxDMQNFYW9epWgsI4aNf1cLH6
FKUzGFhHhhs/Vcr1/nJHPV4megkXbhK+t6zMB1FK3XIhDVaR05jy0NEhYN1qH651rX0dDu2O6wxe
F1ljuDfzE6JgzGMPplY767qyQ2Fm7TLr3c+wSK+1k92VRLco/INbIXswWjbLwYUYBm70HGpPp5fj
QhxZ9opYoA5w1rzq0QovQPRUhpuIDpWfEm3K9lbBZIsFkRk64eeTPuSje1N+bqlxU569v4GA9eRB
fwJt/dgLV3El11OKVchA8DTAvjdSuQnNTrQEOfNtmiUdrv7yjoE5W2IxJ0yDYUkfTEHn1f7q3wm0
e2CjYWvyq3kRPoE2M3tMW5fcY30fEf0DA5ioNHWo6BFf8UUITmZuGENyLwrHnCvxgh41mQLm0sO7
nLcqlH7VwjR86P8sisOcq8JL0VDEMw2cW8xua4QO16KcNKaomR+crvVu2rMVqoiIkFA/SzhofNZb
h94PWp8wsUV2nAQdSq4oqEl/wLLP2iqHin2Hr/uJgv6n9FzL+zZx2FEy0sfYyMedZuqchraEB2Br
iVjY8djd98sVEN/871FPESM2VQmAJg134mBXW/3co2IUx0K0xGECGAGSqvui8GNosPlTi7MyzNFM
nujrUZs2s+ktyVJ280+mMzyldRBZj7LibY5/OhrHxzy/kSRC1BV/jjOQt+EJvYdd2JMxYI61LDwb
w+GX+EvTMg2QcFu3o9km63eb/AX1+iMc7WV6aoSEpYJR/1AZl63MFA9S1M55ELSAjGD0CHRkO1Cb
eb+4C3QgcFhlnfGH2s3Gru2rREj94IlEqJeuZrJu6+PMfK/pHoaFgMPaj4t6K8J7nzW5YkKprddk
JrD+yGwA+zYLcMzTg0JQlWAHawgnLsFk/aZkJPr0D5+HpmCX+ViEGTYynLfh+Lk328AGSiud8aSi
RkAyxqZAi7rTeQqYNsSo7cIIgxtRzz4J+NG+A/BnX5aLukaCrTjWohBeh7BqHHant9bcv4UgrCcr
8PLsC3ca4G1s0J9OqHvMEmI5BRG1x6lwOmbsJwTnPsOAhHpNmbuKNydCxLSgS7aFlfIuhYX48v0D
hejiRG3b8f3UhzTXla2wsnK09kFLCIGbUqFXaAmAYEHQkXdRgkP+6KWIHC4NTevYTFftWv2Eqt+A
o5i9LJLwTUDB+mib2NSNZu0OludCIOKZVp7IOt702L+bxw7UsaH57eUeqfMGfQxvTV0on24TB0WQ
v0i7BdGYjkbyo/SbjKqndlkzd3Jtt/gY1fDhHTmnG3SqlO7tvvAvp9M+/M7wME7hz4s7/3Dkp1Uu
UiISxGQb1JhttRBqc8/bYBzEjKGbB/dKyjK/HKyj9kyUlI85NGxZxEsZEI71P77gvgP5dxCpUhYz
d4UJDohDAREuFEFRDRAiqxJe2kpjNLhx1WJqE3LaRbHgs0RBY8sGSBacPZ8/S+WaFkXVkaTJc2ba
7ieVbWX1bss9sZk4rs2Iao719XyfjhxmYYEpiaQFA9jcp/ZanCYzaxyWffT+fTPQ/FeM+7iXb7o6
XMkFSectcarNfcxmq2UPLZVWUjYdPw5Ew6TJFldOIdp9q/HPNpNgJcV2pFPkiDWe7FtkKGNjmSSe
t2sojeBkDnieryKPPGYsbbJTTPWP3jYULpSuRHR36kK9WbkWwB045zR7hnP8/u+rZ2XpJSbM7AHY
dEJsXfB4zJlI5YsApkLi7FaZfa4CUGWmza2yGtAC7sQV3lS32+x/5sUeiALu1oYGtKxqEEYNvc8p
7on7J76qTQNNVO4hismG3y5VV3CN1NTGdQpyNpOFDzwHpCd/HABTwAdLGpson72h5Ln5r2xPq+Ib
pVvs4qclA7QpBRNuWLeZDpT4ALAcoJBWlt87JHOUUpNfOY2+EiqD3JzTdi22ok3QZMBJ4In/Scab
jegCb3N8dkKnRiSXEy0ksIV8fXEDAOQzFKNR7YnGOpT3IFualRJS6HerXbpRgWP9JcsWu9QHU5UL
zFZOjJRPpS5K5CJPMMNIIoOEIbNLBR9jpGD4yGd/6Yo1ng71xNguTnD6oZ4K7EwayQYLGQKMqtZP
kD7n6OUyvahmSNvRkrQ7+yevfwOSlhcWaxtmVzIrcrtOaLba1tQY6KRMtcVlOU8ladgyYlC1A27B
Amm3RyFSFUdiFZ3pT7UvVWG0ewoPPDw0PrnCYXaRgxOyb5yFU47G6a7l2YX+DH6pRq5Y8eT9k6HM
K5d8q8IJZWCfu5ugydm/1GBkbo1A+7WVTeGW4SsQsWeibDJQQmDkX1553GRBDfQ+VDIc7bp3Ustu
XX+22s6aTYsmU0QYuCAZVD/2Jo+hdonBdXoltnrRt12OXLbRtN4DHe291ElIcZS1K8CC+RP1lh9y
CoqW2wz9cqMW4tSXzfMF1KnomCUJaWdYchn7+tZ6hkF1olDEMMeZMqTgWX5N13EBcypAT2BUb3Me
81vDh935h/j37I8fAOaog4DM7XCl1KdSfjo7+knPV9lmM7DyGswPFMzVCPiIRTEqIJZ36M9o+f2x
+InfZ6uSKx0QJN4RM86En5UdtsuTiUBr/CEM4dTZTW64dfM3f6oe/PiZZPaFw76/zsnn7+HO6nzO
yFX7FTmlDva/9L9rc3mXkDk3aypSrWv2mXhUL5ygUl21RIC2EmAWlIArlQ7NOfF2yx38aG/fD5QA
h4mI98cnJfi+qyqRqa+xo74NfPzsuD0bnVtnBBhewwMPL+Wd7kxojtqiakUikyIODNd26KCoajEe
T8rRmczliX4mM8BeSwohj4FufbynXe70IF1kkvQzzpVIIskXhlcge0x0uWyK80emP4h4UbP1gBs8
YT1NZn9fWsVEsUOyxbkHiYdmyhL/heBPl2z2c0N6q9Y3zrSRDHN1grbQHL0Jb0dcFYa5qbhimQu3
lJu9xuw0HaasFBhr0vPtWWIWWLqV+pCdLwMl11oF/Eh8as9iUnbxX4ZlcqGg6F4XJ3WoG+29++Kj
eDmCrqPcOuZgCPAq4AUOvvVyIk+KPcyRLWaNGPZCQ67a7NlEPYPMLAeMIzoMFsXSkMFaOuFcaJKR
WVegN16Gy6Nw3W4vgycV+nYOTmTiB8rGegy7zFry+DOkwLvsgG92bHT0nRa83KpmhecSwVvkNDwv
KlS6pqpixFGBC7bSzjxzU8a7MFNh7JmFLgDOUlN7C+rDdRB1GBQK/J+NqlWZ6BQDIM+in15VSnKW
afiM7yQ0scx5K13fRzdKZHQkIR7paADtBKVTSaoaDR2/nHxtZHyf7cB+aohDmcjhD1wG4B/snvFv
tOGYOjkt+/NfY7PgdrprwR0j0kuruDNKc1Mao+GIgJPCsfWxERoVmgTohuXKz3fWmCBcHyaasjSo
PUZS0K6Q8ETJDHLWXhWIpZkbAV5WGuGPZSKENIzwHT1UfRlmJ/zAC7XrrIm6cRhh2eH5jRlw/j3W
rMPB1t2w9goAuNBGoDns2slEAugpPOf00lW0KpWCQR5krV0XZmE4w8cRzLKvoR2Fn2UjAbVrANVt
+QyEOIzhrrftcr7SrPhpkpg77pMZ9dk3ZY74oU5kUqRJak1Hanjz9JSLlvpKG/xJ5Ls+OJQCSuNM
xnuAGANTNQ+9aRCITwlCk1O5RIwOoDK9UTEFtPFBYKGDdoCsLimmez9E3l/ssw0DzP/2IO64t0oU
VRaNViillc9wK6MmANicxxB2lZI7jxzkoeQTYJPKzMH601GkIJPtNpjPUJ+lRCZEDJLgENFwB4e5
xUalddIwJl1RdxXCkVOqsnpwvcKIn5AIBV/DDx6vqVSS+HXiMZhfdhIA2qc0Y+Nf9OpzGoxAPVtX
c/+W8GSASLQ4jPAUpsAP9b2Z200gLYnz2k6mXnQCNVZF1MoU3BmvAeQDuzM=
`protect end_protected
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity insn_rom is
  port (
    a : in STD_LOGIC_VECTOR ( 3 downto 0 );
    spo : out STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of insn_rom : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of insn_rom : entity is "insn_rom,dist_mem_gen_v8_0_14,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of insn_rom : entity is "yes";
  attribute x_core_info : string;
  attribute x_core_info of insn_rom : entity is "dist_mem_gen_v8_0_14,Vivado 2023.2";
end insn_rom;

architecture STRUCTURE of insn_rom is
  signal \<const0>\ : STD_LOGIC;
  signal \^spo\ : STD_LOGIC_VECTOR ( 28 downto 0 );
  signal NLW_U0_dpo_UNCONNECTED : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal NLW_U0_qdpo_UNCONNECTED : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal NLW_U0_qspo_UNCONNECTED : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal NLW_U0_spo_UNCONNECTED : STD_LOGIC_VECTOR ( 31 downto 4 );
  attribute C_FAMILY : string;
  attribute C_FAMILY of U0 : label is "artix7";
  attribute C_HAS_D : integer;
  attribute C_HAS_D of U0 : label is 0;
  attribute C_HAS_DPO : integer;
  attribute C_HAS_DPO of U0 : label is 0;
  attribute C_HAS_DPRA : integer;
  attribute C_HAS_DPRA of U0 : label is 0;
  attribute C_HAS_I_CE : integer;
  attribute C_HAS_I_CE of U0 : label is 0;
  attribute C_HAS_QDPO : integer;
  attribute C_HAS_QDPO of U0 : label is 0;
  attribute C_HAS_QDPO_CE : integer;
  attribute C_HAS_QDPO_CE of U0 : label is 0;
  attribute C_HAS_QDPO_CLK : integer;
  attribute C_HAS_QDPO_CLK of U0 : label is 0;
  attribute C_HAS_QDPO_RST : integer;
  attribute C_HAS_QDPO_RST of U0 : label is 0;
  attribute C_HAS_QDPO_SRST : integer;
  attribute C_HAS_QDPO_SRST of U0 : label is 0;
  attribute C_HAS_WE : integer;
  attribute C_HAS_WE of U0 : label is 0;
  attribute C_MEM_TYPE : integer;
  attribute C_MEM_TYPE of U0 : label is 0;
  attribute C_PIPELINE_STAGES : integer;
  attribute C_PIPELINE_STAGES of U0 : label is 0;
  attribute C_QCE_JOINED : integer;
  attribute C_QCE_JOINED of U0 : label is 0;
  attribute C_QUALIFY_WE : integer;
  attribute C_QUALIFY_WE of U0 : label is 0;
  attribute C_REG_DPRA_INPUT : integer;
  attribute C_REG_DPRA_INPUT of U0 : label is 0;
  attribute c_addr_width : integer;
  attribute c_addr_width of U0 : label is 4;
  attribute c_default_data : string;
  attribute c_default_data of U0 : label is "0";
  attribute c_depth : integer;
  attribute c_depth of U0 : label is 16;
  attribute c_elaboration_dir : string;
  attribute c_elaboration_dir of U0 : label is "./";
  attribute c_has_clk : integer;
  attribute c_has_clk of U0 : label is 0;
  attribute c_has_qspo : integer;
  attribute c_has_qspo of U0 : label is 0;
  attribute c_has_qspo_ce : integer;
  attribute c_has_qspo_ce of U0 : label is 0;
  attribute c_has_qspo_rst : integer;
  attribute c_has_qspo_rst of U0 : label is 0;
  attribute c_has_qspo_srst : integer;
  attribute c_has_qspo_srst of U0 : label is 0;
  attribute c_has_spo : integer;
  attribute c_has_spo of U0 : label is 1;
  attribute c_mem_init_file : string;
  attribute c_mem_init_file of U0 : label is "insn_rom.mif";
  attribute c_parser_type : integer;
  attribute c_parser_type of U0 : label is 1;
  attribute c_read_mif : integer;
  attribute c_read_mif of U0 : label is 1;
  attribute c_reg_a_d_inputs : integer;
  attribute c_reg_a_d_inputs of U0 : label is 0;
  attribute c_sync_enable : integer;
  attribute c_sync_enable of U0 : label is 1;
  attribute c_width : integer;
  attribute c_width of U0 : label is 32;
  attribute is_du_within_envelope : string;
  attribute is_du_within_envelope of U0 : label is "true";
begin
  spo(31) <= \<const0>\;
  spo(30) <= \<const0>\;
  spo(29) <= \<const0>\;
  spo(28 downto 26) <= \^spo\(28 downto 26);
  spo(25) <= \<const0>\;
  spo(24) <= \<const0>\;
  spo(23) <= \<const0>\;
  spo(22) <= \^spo\(22);
  spo(21) <= \<const0>\;
  spo(20) <= \<const0>\;
  spo(19) <= \<const0>\;
  spo(18) <= \<const0>\;
  spo(17) <= \<const0>\;
  spo(16) <= \<const0>\;
  spo(15) <= \<const0>\;
  spo(14) <= \<const0>\;
  spo(13) <= \<const0>\;
  spo(12) <= \<const0>\;
  spo(11) <= \<const0>\;
  spo(10) <= \<const0>\;
  spo(9) <= \<const0>\;
  spo(8) <= \<const0>\;
  spo(7) <= \<const0>\;
  spo(6) <= \<const0>\;
  spo(5) <= \<const0>\;
  spo(4) <= \<const0>\;
  spo(3 downto 0) <= \^spo\(3 downto 0);
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
U0: entity work.insn_rom_dist_mem_gen_v8_0_14
     port map (
      a(3 downto 0) => a(3 downto 0),
      clk => '0',
      d(31 downto 0) => B"00000000000000000000000000000000",
      dpo(31 downto 0) => NLW_U0_dpo_UNCONNECTED(31 downto 0),
      dpra(3 downto 0) => B"0000",
      i_ce => '1',
      qdpo(31 downto 0) => NLW_U0_qdpo_UNCONNECTED(31 downto 0),
      qdpo_ce => '1',
      qdpo_clk => '0',
      qdpo_rst => '0',
      qdpo_srst => '0',
      qspo(31 downto 0) => NLW_U0_qspo_UNCONNECTED(31 downto 0),
      qspo_ce => '1',
      qspo_rst => '0',
      qspo_srst => '0',
      spo(31 downto 29) => NLW_U0_spo_UNCONNECTED(31 downto 29),
      spo(28 downto 26) => \^spo\(28 downto 26),
      spo(25 downto 23) => NLW_U0_spo_UNCONNECTED(25 downto 23),
      spo(22) => \^spo\(22),
      spo(21 downto 4) => NLW_U0_spo_UNCONNECTED(21 downto 4),
      spo(3 downto 0) => \^spo\(3 downto 0),
      we => '0'
    );
end STRUCTURE;
