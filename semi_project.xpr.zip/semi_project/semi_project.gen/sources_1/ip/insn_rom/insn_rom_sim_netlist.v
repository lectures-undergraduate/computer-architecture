// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2023.2 (win64) Build 4029153 Fri Oct 13 20:14:34 MDT 2023
// Date        : Thu Jun 18 21:59:32 2026
// Host        : DESKTOP-D1BDUE3 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {d:/Project
//               Folders/Vivado_Repos/semi_project.xpr/semi_project/semi_project.gen/sources_1/ip/insn_rom/insn_rom_sim_netlist.v}
// Design      : insn_rom
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "insn_rom,dist_mem_gen_v8_0_14,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "dist_mem_gen_v8_0_14,Vivado 2023.2" *) 
(* NotValidForBitStream *)
module insn_rom
   (a,
    spo);
  input [3:0]a;
  output [31:0]spo;

  wire \<const0> ;
  wire [3:0]a;
  wire [28:0]\^spo ;
  wire [31:0]NLW_U0_dpo_UNCONNECTED;
  wire [31:0]NLW_U0_qdpo_UNCONNECTED;
  wire [31:0]NLW_U0_qspo_UNCONNECTED;
  wire [31:4]NLW_U0_spo_UNCONNECTED;

  assign spo[31] = \<const0> ;
  assign spo[30] = \<const0> ;
  assign spo[29] = \<const0> ;
  assign spo[28:26] = \^spo [28:26];
  assign spo[25] = \<const0> ;
  assign spo[24] = \<const0> ;
  assign spo[23] = \<const0> ;
  assign spo[22] = \^spo [22];
  assign spo[21] = \<const0> ;
  assign spo[20] = \<const0> ;
  assign spo[19] = \<const0> ;
  assign spo[18] = \<const0> ;
  assign spo[17] = \<const0> ;
  assign spo[16] = \<const0> ;
  assign spo[15] = \<const0> ;
  assign spo[14] = \<const0> ;
  assign spo[13] = \<const0> ;
  assign spo[12] = \<const0> ;
  assign spo[11] = \<const0> ;
  assign spo[10] = \<const0> ;
  assign spo[9] = \<const0> ;
  assign spo[8] = \<const0> ;
  assign spo[7] = \<const0> ;
  assign spo[6] = \<const0> ;
  assign spo[5] = \<const0> ;
  assign spo[4] = \<const0> ;
  assign spo[3:0] = \^spo [3:0];
  GND GND
       (.G(\<const0> ));
  (* C_FAMILY = "artix7" *) 
  (* C_HAS_D = "0" *) 
  (* C_HAS_DPO = "0" *) 
  (* C_HAS_DPRA = "0" *) 
  (* C_HAS_I_CE = "0" *) 
  (* C_HAS_QDPO = "0" *) 
  (* C_HAS_QDPO_CE = "0" *) 
  (* C_HAS_QDPO_CLK = "0" *) 
  (* C_HAS_QDPO_RST = "0" *) 
  (* C_HAS_QDPO_SRST = "0" *) 
  (* C_HAS_WE = "0" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_PIPELINE_STAGES = "0" *) 
  (* C_QCE_JOINED = "0" *) 
  (* C_QUALIFY_WE = "0" *) 
  (* C_REG_DPRA_INPUT = "0" *) 
  (* c_addr_width = "4" *) 
  (* c_default_data = "0" *) 
  (* c_depth = "16" *) 
  (* c_elaboration_dir = "./" *) 
  (* c_has_clk = "0" *) 
  (* c_has_qspo = "0" *) 
  (* c_has_qspo_ce = "0" *) 
  (* c_has_qspo_rst = "0" *) 
  (* c_has_qspo_srst = "0" *) 
  (* c_has_spo = "1" *) 
  (* c_mem_init_file = "insn_rom.mif" *) 
  (* c_parser_type = "1" *) 
  (* c_read_mif = "1" *) 
  (* c_reg_a_d_inputs = "0" *) 
  (* c_sync_enable = "1" *) 
  (* c_width = "32" *) 
  (* is_du_within_envelope = "true" *) 
  insn_rom_dist_mem_gen_v8_0_14 U0
       (.a(a),
        .clk(1'b0),
        .d({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .dpo(NLW_U0_dpo_UNCONNECTED[31:0]),
        .dpra({1'b0,1'b0,1'b0,1'b0}),
        .i_ce(1'b1),
        .qdpo(NLW_U0_qdpo_UNCONNECTED[31:0]),
        .qdpo_ce(1'b1),
        .qdpo_clk(1'b0),
        .qdpo_rst(1'b0),
        .qdpo_srst(1'b0),
        .qspo(NLW_U0_qspo_UNCONNECTED[31:0]),
        .qspo_ce(1'b1),
        .qspo_rst(1'b0),
        .qspo_srst(1'b0),
        .spo({NLW_U0_spo_UNCONNECTED[31:29],\^spo }),
        .we(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2023.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
uwBH4JaTzmENPjp1VK18+NmHqz3idKCCPayqakkK6bYDVk0JtRfycJYNxbcnLmlw5yuLTcDXBBKk
FqBPE2n7wWKg9tfz2Y8PrWAvnbsIFMfxBK8sfWUf8PPnz8vUwwMHjbXUWcgCgvtygj/TbB+jcZ8Z
CjYnBZ8tNdKOO1iDLpQ=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Ff7o4KDFniNgPFT3cDZtw4HhiKzFbOFtLXtuci0MZhgQ8oZ15BcuowAfxUJXngU8JkWI9cbWKkG8
h/PODwnWEt4eK4VDKRk6Hw3QkZiKAa1N3QupC8D5bR7vJ/+RhJwSayz9t2JpdZaEhKgCgqTcX6oZ
4fCEOmSTUWVob+DXV4UfaMyfVm5VI0wxZ7q0mjFx+pdkt56PuNREX9kH4a9Ma1P0sYo8XaTpANLa
JC6eXOuUQlp40M9F/NL1Xajpys0YfGx8AveMAFEyfRmHZs+NbXmny/79vednrm+FhwtS9LveegmF
NZW9jiiR+9Igeraaz+QXPc6JO/nCDTr4Fuwusg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
enb/INzHPP7GNdz8dyyqgVCJiMs9JXcjMywZXhzPersGm0A258UOUwtOqcF1rO7lnrKwTeWbNFVN
dO3BxXBpzGnYWUqDda208CYV9hTWFhfySQdX58qn1Z8QY5G7KniMCVjaGuPPCfToPOOdbAxR9XUp
XbMr0vrZKWxz8nBhGYc=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
RKZNANfa63/n14iwmSxsB/UeV76BNqjEiYgjlZ2LdFWOArCv6D+jhC4sjGMiaz8GJ8J5kQeiWB0Y
e1+zdHflgzODs6eVC82MlEcfgP0vdDIBn0PP8rVDg5O31eQuJ7n5zn4XJu+vzjpkvJIHKrktAsP4
jg+LRxcTOu0dILImk7Vwgyuwhi8OxNN+jBVbLVxdNj0l5aQMgRZlU/8FVh3u958SH7z/fHnwGaOw
P8QgNv0ZZblWvpxa8TJIwlgVb9354a0eyD9XsKy5VfuUG03nmputxNzUuIUmGtBGCqx+4D4pyCch
j/ixD5iiKRmeKD1/RtGzxmrJap7SAHMuzic1Hw==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
OQMD0qoDy+4W8+jfTV63GDTwmjWvJILCTofeYJTZqWc2KhrzQXwVMW48dTyIriC6bA4bmXD5BwcB
W2gGbVUvY1Y1+wEFEwYIC0LiPrJO0DhpM1JhP2vkxnTEwaODiEp5x3XqHgsiys0I2/9mE4z4Hlbl
jzftQ/8sVSYokhMp9eaIHk3HNCSBllv90qeBfH3fOdVI2gA1r/22PktttbkyKji24r7jM5o4aMIc
Sp6u0DCnD2cSPCuCuMW3A9sFRuTKbXiLAeeymFIAXHKYQgWXXOqmbKHrk4GviHQyz31C9d+hm6dh
RMtaCyWnhqo3QE/QxP0TsYk3CgkjDCU+KK/ozA==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2022_10", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
uV1eryjGs1SHbpKIAk5r3BY2SLKX9RlfGw6gbw/UtzBYt4U7vTBIy+x767ojEcmbGLos8kr8vilV
cnNOnsbu7vOAUIe+1PgpaPaCkv2OTPXaE0tfps6+Q6D3zB6j2a2FE1gRIPOniwAdlIn69jL2tuWD
M2BN1efQhi0lZHuKtTgzBOVXIg+zbTiH2k2kHWThOi6WayoBEny+g88wRi6pUBeB6aW3ezFYNmsl
zeOY9xmt+UhRMcr87DCcZdmjsIk6VrsIKF60y93pM0IoQ56iWpQ2OKZK+Ng9qC+pNHBEYEhiMQFb
kUesHtcFOIS7Ok6S9O9SMgf7lMQFOh9w0L31UA==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GM2VxmvaiVBg1DsqOLewt6rcWtfH/Gj1QS7fUSMudF5qJ2fn+TXd8kcCwwrxdcXNXjoVi2As5jmL
yw1/NZreemrkS1YCJJDxmnE8CW2q9/4N4a79kApF1VfD5XdpaULhVn+Eb+jXCQFG+GEEOvnPb0Me
bbfRkfc0DAIWgtG2D81EQ28mg7KAWtsDpdUCi+BKdIAj8RXoTiQbFbiBeT7EiRIrz2PQF9nhQBfF
FjlrCNwDP4hRQJQeZcf/1Pl8SFyKGQb6iVF+VhhCVCunL7VBmzaCOW/gowPM7hRM2dvzmxcgeKfs
dZx/fy2rk1iokUi+3B+Jc6CycMWbHu8EfCh7iQ==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
NSZoNMCco4gpYPcg8pb9mtee1JxEWDcDzt6wnS0LeSPMi2upLvQXnSQKMvJGGOKStJOcu1eu7x33
4Xa3ApbjbfZ+lgs1PYlyY4V+B2Lio1EEo1uzZVWFrVFvmknOZwj6Gcmj5N/osaiqKaeIw7NTTbyX
HNHOabVsQJ540qnP4u/nzS/h/AQcm0PFLadGZtHJZEzyQDSSdghD/y/OLprdBcInfQDwAxQuJpCy
ExX4lD2WMrCkymNBS9NMH0vYh4kvpYKRO/oHuGcOZVg0p8vfMmz/BJDHuxTcS3FpLT0WxGVcmUIk
cuqKQFiVwwgnW9AfYkbsMrwfl9po2pofaAY2JC5ZTMyO1qEfSu4fxTRJNnDRvW65KkMdJhZFa36p
82hcDlaYvBowndZfMc42Sxt+ZULFDTFN0HT50iteAG1yEvJ9jKBiJla+kDQJB0VD0kj4+k8aBug3
uPKVykvf1/Uaw8NoW591pML42qlh8v1RzAm6aDnPRdsDaCc5Dq9QDPuE

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
oRNld8VrAuP/xHUguZzkh8+wROOItnvw1FQUP5KHjxeh8nudEYH2PGefTPsV73QyEruJanGifjCR
m8XHiIxqAY9fk4CAm+2n67YLFUEHjC1Qri9htrL4W5fnj7OIdzcwttvmGEuGOuYOFA98RcnR0jSL
Nyqq5u/eILCh2MiKiELfsBjRv/WckpboJ+gzO1btduECvdBGjsIcjjHiIzPwNSGxnX3G6zG9OiWq
hXP2Jh0Ril7rGbajit90p+gJpDpuLee/aOh0BUXbYYLU0YIXK8bskgMir7D6cfu5oWDKwYH6/YRR
tFjIhRzFsqwjtmaxUnGTZzxsWGazk+uFfHXl7w==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 7216)
`pragma protect data_block
PyV9x82L3zEM4dXFfTvrX4Q14s00SMXwB1lJzZPDPTQ+wQwSX1iLyZJ0LSp2lV9TC/gxpMW2FF8Z
21B4y2jZibfGqR8LIFT3iCOr+8m8IMp7rBvliAAkAIOG4woCRMK9B65OavoKxE48hzTSKMndG6Sz
EsXcJLa08RdkxgF2IFCojSwuxM4xg51YoOGwIj9Bb4m3zeirN5MxvSuXx2Qk2YjE9Y+1Yj9Kq6DV
XO/0r2FRWriqNK3alpw6LeSs0Y2RSpsMIH5lN1/spIGXq7GsSDM+om5n+9FtxoUMuRcdK+34rGt5
ICRAYCbWF+Nx7Xu/90iiXlEu7lNTEo7W5DO1LCnfAmwRnrC1o1IrwtQb+dpFuuoM4/qgZV0iIjOP
H2JWgAId/ZkAuIKY6ANfyZDc/LTCaOnJFn2iUAkT8a84NQ33VfR8gij8eWHwIQe35w/ygmswO90b
SGm0ZUmXzOuu4moetb/9ztLY4OeKJMKQT8SAr0aHWRQM2+cS57HkUOaxs02+OQChcL09gUG1OSGk
ZoHlnxLEBFFtwO8TbKcarElfdXBBtewYatR1TNzVL2uvUhK773oBbPZcG6u6gIBHa5NtpX0A8D1o
mzfaJ7IeLucsYnSP3okvDPKgEP/l/fn5sr1cd1IJXicCw64qlcfi9NBXcHtl2qfJJVgsZjz8xGr/
L7yjUiPdMcR1G2ea5tFyl1xCG5YC4PC3sc2TQzo/jxaVKsPzB+bj3I7e3p0KhysocaXsp5j54eH/
4RbXuhDkssBVn+AlRc4prDrMTzBc2erR4v1mzDcJbdVIXAkl8BLYisu/W5suGnxEpS2NEO8BoUFj
JVSLdcoK3Drs+4o5m7RiSNNN1hsRyHX8eUq8JNM3FbaJuT2vJN02wx4zIj9sZbavXKawdVNeAVcr
e6V0QotNRTc2vOACfHJWx9OLl9g5rLCjqQ+7DucOHL+6mMvw+Q7HiAXGUS/sZoE9wVfuSrwXFe2X
u2Zhgv7aNCgoRvumEiirka8Dgg7qPCwLr/UR5Zs3E3aQc5XVoQwubNnPS1yhRqeVgVOcZib0wwTu
U4dSlqewq/z1UjjmDp2ZaCtHW4nfdWuQ/FzmyZwFL7syEZnwgg7dIG4Zk5c4ZvbpVLPfea/33BUO
0MN9rIEw6zHb1VczLlimaetme7h1UmLKP0Tr5SBxtxUvGuT1SHVHbT3HVhgtiJDCBaIGZMUQjWsW
hCC6cNzpWXFon6lttwPyDF/uqtwMBNPDOUHGlKrT5yzaSRDmEI0XxcY2GtznKTUd2i06P+/N/pZ6
xsi4eWQlo7NlOACQGszSvjDxiSbyxF0bBjySTfPdgRrR9fQNaItKtd4Mal/rRZaxD8lsI6uN+YoL
AN433/7mmt6/3U+KWYaXKerxkxS5JClef1Q5JKBf8CRn0j/UsYKtCwegnvA1CdA3lHua5GQombE/
brz8Eukd2FFsGX7GgfhZ2mpb/FWydLsRyGxVcRPBByiGL3qJ9lQWkX8kYDkd2IeCwSva/6rMU05W
z4m8eJvahxk3K/S0tWrinx3kvsglIHnQSXmbwO2kk36GYhjiuW9n7HukAGR4svqtNI9SmmX3sK9K
1JyXUx50FbrNeCohv89cZLj8w/Qqw2nivPahKxbiD9RcogIkY9IFHE9JimPm2eVaWRgpu8k/ML5I
4+mvqZpOi/6x7iN6WkXIR74sHxtHeZkWAPVVHfD2e8T6ckwMsMR1zuUbEwnBnQ6riz279Gc1+5Ko
DF4FDHrZNRjx/fqbjxiF4FfMvnPRnA19WLNJWvva9zpFvrCvb5POxO3ctdD/owNToZYvkx+xB4w1
i6BNbJY5xiRDMgqdeQ6yTeE9zkUNlB5Mg/6y2dYKmI0ppssebGp+cnmIT7kgqMTmCz3Bx8vX0xNh
f1tgkEIjuQtB/cnbAI+MfpxdG99rg7FiB2NRFTol1RPBu4Ryun7eiJHxz4n0p9gn73kQAsAMMzd7
cXOCam0PUvqn6a80NoRUyzDKVIkF3psGLU+YvcFToXvS+lsg0ojTIk/3/LQlZ0OcKWaaZ3mnSKmI
SAUeyO2hjhkeWaivV1TgdnRNdHvlmDdDfNAx/QDcm4AEyJ22OQth1D16sMF09Kd1N+3HxvAynsGL
sy42kJMtF4HB21XlQikEQboZkbG781E3CjvrAE2KcvMue4qfg9POgT7gCQtbZjlqqtiZ7JjJsWTV
Cuq0b9Q8bDwdrCjj9831ci/nyJSfE1BofIWBfqQz7zSeuaw8hHU/ismpVVIEYt/SAf/4BK1Z11DX
+XUkLvQ6hn7LboKwMO9YwBEA+xyC5NX6mi3ZueC6V9WA9YFEaGehzi6PhcCi0RvLGS7p4Bo8aesn
6bzTQNfDCl2+x6DE5BSoI/YTlonXXICTn29jaiL8I67uCS9nQeP9EBCcujoH7ueNQaTUBzTgVACS
XqK2lef5KV2i2NHFVRvbo5m35kgNMjyOL/sJdKTq/ugD97zDYyVSQRkc1aUmBlps3WYtcshOdf8r
/qFeJR70FV2oTdN3iaLTXOHdUYEs0zuQu6pEUI/4/J9kYCzItmvKwcHJKx8yOtUuV7VZr75oZDT4
TCa52upz7U2VJAQit3B1rzEIIn+iyu6AAd4pL0Qoew27j1tOqg3u7eofby9SFQ7Ea0kwNv4BEbG/
yzsiIfl6gW9gfZwwnG5A9y+ChbTJe/Y2wRLR8J8gCkh7mrFyLKQN7QeGlowmlJdCg/AlD8OYMpwZ
hwMjFdlwByju0gzLXMQo40eIIUzf4PuWsNI+iiUiJiCC8DBfpeakTxfuccBpeD/YWjJLXh5+4sGY
0gEZSUIeVAFHUaeqyeeFjNyeLB3/yHQsUZroPKTxr+5NR5SomxhwXjC8BvIEHITF8ZMAyFwS0kt+
cYtD1cauT1btP4eT3elhO/5aUmbxLNSyGdYH5Ozsw26ViUX3clQrLqtelpndcMtJLQSlJ4ZKnsTL
hXQL2GvIUkQlCpGcwb9TCqsV4TKkA9ZtBVClthAwmm3Rkog9uzofWR5RIzgN50OW3uMpfN5BrbZ8
VKMrME1/axi9zr4vCoDqQxR5yxTpSPUj7lHe17ONhBFlsuO7FOSf24lQaJi79zH4O7CWIlzhydWi
se/Q25eXb95XunctfbSwYj9kOWyiN32ZJ3Y71JQ+IVArZF8bRTQ551OxldVXw/FOjQaq/MVL5Yku
xAZ6UNdUP5RsaKLyARFN/vW/QBwVIv6BDbHzawgVojgtYsImjK1i74L5Qrw/xBIg9O8zSusODatG
Wfm/T1oNyjrvpA7FUU8Avx6huTCSbH8oFQai/lCfrJgTh/fDWH64NIhaoDv4NWylWIWPXggM23PO
Tdrj8OOaRdR2t8QlPt265wKoNJuvHCqUElj8L900H/QblPDqwNLc+d1aj4jWnQHH19ZnpMXfQv7R
ZwX3nlB0dNwLi/2tpOz/Zd3ecl8pCuPMPyoQitUZUixYgnDZ+uhJaMxyWwV1UAW3YBt30Ezt1IIV
Ui2GQc6463Rvcbr2pxZ7XAXYi3qftEJOlDSd2NlUFYFH6Yv9sFXUTlfgIsFn6iM4+wpgxE4Ur/6B
YcyjNJu2OQLQgN2onV0sk+S61H/jAv5e3L9Xm1NRL4iWsUpiNde8Axeje/crie1OaKvS3e1plHsv
zUpdaAem3JFM4G3Io6zxQThArIkSYEOkYh0JIjJi6eVQt3cdrT0M9FxOUyKyQIhLs1TRQjuWyFsC
xG2rNoiN8hqrj/LXwRoe4zwuwfq83KlJGffjXHdeLECblPNZqm0naHFaEAanZK0EGIBKd6CHcpEj
nhjHNwRqa/tri4m31DrCiUBtpK3k43R28eUJgsizTPqzr8Jv1RRfRMRJV9x/fAsWLDkUiq0+7JRx
J36P9R6jFXSYMRcLwGi7U2mUFKOFDzzrHqM1aJz3M/KgJEY3Uei4eutIJB2FCXxXjj3scmNxUjLK
vD4m/1um7Hwm2qP3vdEnOjNNDwSX/zY3q9AWQf0O2rnQKLVg11GU9hu6N7awAEZTYPj1BhGmLaTv
ORl/ukFVh398Gexuav5PrbbSz0hLZelmWvCuhWT1Nz0f7AdBQdyHFuhtkRjwqWHX58mmlJO5B6Ro
cKCOz4sOfjCjQgYSS7HduOqKkNW8SrYNGq13cwluqD8ykjcMoXQr+Ee/4R/ZPBIl6QI2qXUFfMuZ
OjXHmfWfNsI//E3zheZ4ZVsViM14MMqNdNNsv9E89N1gfN5DOLQW7Ejmnd+eGEr1pu+9V2NDe9hg
1tqpWEMKw4AAmVUCsNd1OgLc44oTsPAhT+Dk5t5pquHZrCjX1BOkK/GWHC31gB1JbMSes0/9UoEH
cSlGCGDqiuHUuyBa+2uv1i5w+MyE7yy7ipZyS79A/mT7gr9ZZ19kmghkHsvqsUKCWKn1I9vm4IyL
iGvdywl8zMQIDjKseCy9nh2XYT+TBB2fwgcz7dJh9JX+entlXxoGEpeeTcSBZJtMu2ir9hf8BW1Q
dE4FgOe9DxfNHigwyC8JUvv+mNwufXit06MFcCQonZCzW/LUUajkxn3OdmDquIRz9QygB/pX/QL4
QafdUfJpLyRCAboCCJFZPDeOP/HiYsNCF+sa9KMrNSDmG8SmdQo+enqzoO8OR2ULVrIPvRMmhdl4
Kzee0hOStIEVyL0GCoHyqcHXi1bFc+tkW4WhCmGCfhbcB0LoAqk8w03CXs7TemcfnCrGYU2O0yrq
D9yYe6iS1hH34DBfqEjWxOr3kYA5fUZKaepEtYcW5XdNJKOvLfkUB+ianWkPjusxjbbwt4SvVLc+
mXTPwvHfoYOhMaW9eGoFDgbaB6TsYVnOpW82JE9h0K6c9o2ul8RlGvvOnTrEuYRIbkEYsV2nbd6e
ONoWqPB7e2GJpw+JTjw9TabZg5LI3CgUqFDKneufkNzJsWu6jjOZdxnNwJmx5PlwbxHGlLrpr+co
/LgJmI5xgDQuA6lX9BjlmAaxvzsvPng0cUwBxcPd/ck+kP0Pvjk9VlN6LBGP2wT4iaBgo7zeobOX
0RDUgMfU3lImVJLlJ6yx0+FA717d/s+j5Gl8K+fqhdVuUgQBSg/Jd6I6uooLRbsOw+WGvXqVodbl
p6jWpLhXNU8WpVsmNou4OFi586Kb85C9s6Wxhch5hVHnHAH37KtfNjiuNwcqI9hEvLM3uR1KYzr6
BbrV5anKksezhDwM6sn3Ro4xrkvh6rGcI//WkMO6FyeBbbcASVpPtUNafoH8wG5j/IUTUoLGZKJ+
cW6gwGwGyV4oNSzGYVb0F+Y1TBbq0hzpWAiZWzSNlUZ1U0NxmCEXalTPn1gVphEJcrh4oIuCVenO
7MRF64YqCh2KkJ2YurmFQfcANJlWjqCTjdo6uYTCWW/7BEXnsvRJuif5SAvatew6+G3/EZKYRRJL
e7+FcTVw/GrP+npoOVdXDpOOAp+0ir4/3yL/G5y4RVQqpIxuoqgvw5XHkxjXHdusaONunrRWJiYl
L0wtLa/aKgnHgAaUV75b87f+cClf7rB1H24o9RB6qYBXvCNH5DifPn8BvkcdqHegVmBQaZkYulxr
1P8NH/cQkk61RKJc+0HG3730gH11/fmpNGCGGaqk9DHBiAre9zgESGcvCe5NBcCwJYbC6yMvPCIG
KhtVD/gNoLESn8FDG40pwiwRnXtfNRM1oxb8P7H21D1zyJoYUoj6uAQivPkdSWDdw+OJppn2zL7d
fMRRJNHBNw2+8EwuPlZhwXNJ1WsJfqg8QwebKdCgQmCqCAvEdQwabVMeztTMPkOCCshwZvqQXWlR
u9Ftv7fLVcgHPLIkFm5qOpuBITnBJSR6kUOCZ4HclApgTxIcCaDHQRQyISR/gJ0j3DidB/LOL52W
U+oc/RUtl1V3SX6LC9OHcQ5fcKhMQdFgbGv5FFXQ7UNbYciaFc0Khz4xqIraRvIoqHGn5TOUCR76
bPUxliEk5uKR34VI42D7WAGpSxsn1EjAHWYuj4OOB70mCRXkQRNMdCumICS2CsWXYPIq0AVu0xHU
F3fWztL/wQsZkq0VZ+x8J83pDTV4W4HYVGVdl5mUTEXQHAgcZ94QoNRGZQBG+8Fvi1mCtuMzx0MV
E82kVA9Cdt7BmH6ASckr2+6c2mXMGipTrlhHFvpcK3FDhuqu78BTCn3qOcGRUUljqYuWaBmYSIzg
FR4clw2Rbg8/XEhMQSXka9JoSFE6V0bfYIcayTxgIT0SGzkIkv+/PiqjkSQux6/EpKtC0Zbu05N2
7tHyY0JTmf+IXVl4cKtJzwRSgVwJ5/0QoW1b876evTXAuubqotqv0HtXmIFcqay9itbEXRNPJ1m3
45EYJ3ToZk8xJl0HE+wv8p94JYI/lwK13tNNXNijfTGUeGcqKW3vDFzUNu3IUBzrpcwJ/ZHLft8/
T6nqdKHerwwRNqb080kVPl62jqwcdzGmf1D/RyyoXxbnFIjmGPcxNo9M9pUOGzSYsdBVR6Pu3TXF
RHcMTK3F57S2n1RTLCSu6QToaggXfWVeOXZpevOXcZDq5nHgnBYitXzwl3F15ajYlVb6sBvfx5bQ
j7oj+CkLiKpBuu/gDPAHc2v2YNPp96SqrZmvS5msK0hQJnwCqc7le1E25ZXu9ZQ0a+ctH48pfqJp
wLIUP5r73ZdpFWjxjrGLgV3U0XqeDsVTBWp2+XQHVHacqjuiOkZEqHX4i2lQw0Ct+YBDz57T81Qm
bKOHi7CZV0gvgfxp68+3sFmTfv/WpEXmQoDJbjcpd8T2VC99NBNjInZJMt5/ZAp2gIvhBoE02QLV
c6gsos2/l5BBcZKI7je0xGXXZgE453SeNH7l6Wj+5kcCF86oMnm4MdFrOTCBgPHbZZcrfETUIUoH
4omec1+3JJKwv/ZPxgUFN3XfW67eRNhA96J6UOoP2wLzTt2L7s5fWHjSMJmF5AYu+HSNT2LIDWgZ
XqWtzv77y1mxsG3F6Cd2XaIMs6MsQ2M1ZjGawXTKQaPm6ptNNxoKKH+r23BReE3lWTLU715sxqHP
exSR1lvis7LbeRrzWnwC5OXftRwLNJFaFzIKnNliabH//l7Gics0bocNVvPRNtWgAPwlzW3JCN6y
1b/MTHTZVwC+rttWO7vQQjtKRfS8x+edp+fRXIUQvfd29DDMNPWX4tJp127Ca5R5ZLUAfQ398s0m
FO8OT4mtno/EMc+VuXGA2XsSjmEWP6+i8tI6DmPVyljrToSTL5wTtlW3rjyacdqSKGbUZ/woG2Px
fPVsBJ5dPEShbbsCIPuPIeTHxVMfjCulKJm0E3CV4m0vnTZ2mfXXbRQZoTYnnHAa3opFi1woCtBK
Y6Z6PTsH6TPfSsqOFEUyu2sc/0zMBmRbeMhM09gSEUy5wxuTUVUVdOvnCZJXWVv2JTkFzuRgbMmb
yE423Hb+vOFm8RTBAcir3Mll4SBGi1vuXiKRefP9tptQmaViIXdvinNWdGygmJ8tAwXARwXohak5
LfdcZ7V/kSElSaF6jf0H+taubla3hXkq/fvsV9HMy36fazYMoXktcedBwZpPS8KWthw7Q4ly7Ln9
vPlrw2yz86zWwwL6mQM/kJFwsVJWSD+YvarEOHSK7eznR0VMXOtTvf9ztgFmN1NZvqeWjL/BhJn4
iVQjweFbkTQ7i72DA9P262YDbCunUiJGVdMOdOr9RMvsaWd2A8OuHDmoU82LQpsla/TnAdV1Ipqp
LxqfRTO5yx/FZzqfdZ4j6N4Z8ctVFdHh+ySHEej/UsBybTfkQLO5vEhOGHn3PTHN4kpdu7CC4jOt
Q7BHwcb5LECVb2BopCar6cbT8FPe4d6ZtBdnLsej2de0aOI3aQzbp+CW3a027bZGeW8YlTyeGrGu
l66B+S3pPGO/87s+VZxtGN4PDooDxpwoZDyH5yMzX6jErLNJHmPvVrndF1gPyPovVi/CcUgx85au
iGPe6j8RlvpgPeRPIYXGeSroquUz6QWDKe2CzztPBU2tbLPSvJ6Y2JgN6xxmlQL/Rw/SdtzY49CJ
ITileG8mXRfq/2fS6auQS4FPgvbdkQ3UzehNB4R7hgA7y1JeRN49hPuVdh/xZhXHR10gI4Z5MSC0
AbIYgkOBTodRoVFTjj6j/2SWeZNV9uWYhVAoalNYmwxi7wlYXdEMpKc1FzegrwwDdNrCL/FNAFxT
jWEsZEv9p8k7WUqByG1GUsoA7f1xZX41gjGfQdCyVQ/yuwu7ycmK/8XNKsdpLE3RVuO0CDZc0SIf
jRUqbEVwkMnt+WQNDRNg9UrUhAbNOdPaGbbpnz6qgyYE/oCWhUfVBY/1UC5P7X7fPzIgp3wbLfhg
Su4H4w5NYqjx1wUiP8xR07Bm05Mx2oLYCc+jRSQyd5z+wJPsIctdwO7c2eOrRPE8tyJo21izODcx
YORgccqqbvm6Zz9czzLc8A3D3wSleebZ5XTlgWmKbefA64iAQMSRqJjgD8k6MBiZLYb/BilrxDeD
kM8iHrjUJZx2hHmSeBXcMj7eXwzsJFxZH5/wO5m9mlLkNpzZUMkKeqf46gdhhSlfzFCVVQsoayIE
1anVaM8CqocL8HD0yqLmpVKMexzYatWM9+VRszTFArx4uBXx7EJuD1oKGO0oiSHImzq4JirpU6GO
RYWVQ6DdEGsdwjcWCXN7+VMeTdGqASxRib9Fib3s364IphUS2tEhEnL5FpSMV9dEFr+7ozjhqOqi
3sUwRxN7SES2FhzeKDTij49Q3abwbfKHZiYzw2TlMeqi7yY1CifwGyyLAnea7q34JDDU/227GhSi
ep4N7cUFcaxfRly431vCNmOSblJemlJZoX/MNo7MsVksV+N/zEjJ8BztuchyF8TX2PDUulIpVA7k
bxcp91/fLR/b5xPB8Y0AVC+7nTV12Zbh71onao6D8ms+yLZD1rmIJZDHKwP8keSuBI0QJoEuUrVs
bLM2MfJP/A6GzqNZL6I4gsv0kvi8sQztwbJbo950yjMWjwfkgZGPEXkYb0yFpdjfm1YhHpN6WMv7
gvBn/3ziD7pz31/ZHyeBubw0+YcIJtwzclTB1xwt8EtCEO7dhJ6YY8fS3o3/AhqPrfsFhXbkFsa2
kyIvLOgiyeW/Yi9d5NTCYFfbeb2DaEV4mDibXmtcS/ymnluQquNrn0ENERS1am8zYJORv0yq1ixP
eA/QK1rrh42QudITz0HAy40ShjUYvw4mBI7Gts0aogRaW7rtKbZEhzNCsULCdHS5+QljZtkLr5Dc
/zKhwJ5jpFl4UtEVT8VDxRPunAHP4ozN00kRQdtl1q5F69ulys14LbYa8AxJrJBRmX+Q8KFHnJlu
lRnHJST+AJ0ID/XB+AD7unXDplI+ivyfPM5unUqy79OLIhm/snVZ2xgJm6X0TH71YsgLa4izj0Xm
8/zoy9/TaQZBMXn6vab2e/RMjH8zqSs2aNQPCrFJC10Ko1Wc7JNk1QGCIMEhRkb981WhLjlt5xt6
vbDvXyI0P9kMQpMyROiYadP3pwAVJGzUeNmVt7LXHHlLr0/sa0EpPfCpp7huCz5S67g9OVqmNYTD
4AZIKnyfjNCjlfgVtDV4w/viE+Q/BP9V5NvaRMve9Mo0BQao7z38AqUV1I1Gcvvj+ZQur/XMQPoL
K8LJ4/g6BfqhnudtmiI+aTyuNqBVdpFpXLMIlmB5vBp8vQ==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
